angular.module('redash', [
  'redash.directives',
  'redash.admin_controllers',
  'redash.controllers',
  'redash.filters',
  'redash.services',
  'redash.renderers',
  'redash.visualization',
  'highchart',
  'angular-growl',
  'angularMoment',
  'ui.bootstrap',
  'smartTable.table',
  'ngResource',
  'ngRoute',
  'ui.select',
  'naif.base64',
  'ui.bootstrap.showErrors',
  'ngSanitize'
]).config([
  '$routeProvider',
  '$locationProvider',
  '$compileProvider',
  'growlProvider',
  'uiSelectConfig',
  function ($routeProvider, $locationProvider, $compileProvider, growlProvider, uiSelectConfig) {
    if (featureFlags.clientSideMetrics) {
      Bucky.setOptions({ host: '/api/metrics' });
      Bucky.requests.monitor('ajax_requsts');
      Bucky.requests.transforms.enable('dashboards', /dashboard\/[\w-]+/gi, '/dashboard');
    }
    function getQuery(Query, $route) {
      var query = Query.get({ 'id': $route.current.params.queryId });
      return query.$promise;
    }
    ;
    uiSelectConfig.theme = 'bootstrap';
    $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|http|data):/);
    $locationProvider.html5Mode(true);
    growlProvider.globalTimeToLive(2000);
    $routeProvider.when('/dashboard/:dashboardSlug', {
      templateUrl: '/views/dashboard.html',
      controller: 'DashboardCtrl',
      reloadOnSearch: false
    });
    $routeProvider.when('/queries', {
      templateUrl: '/views/queries.html',
      controller: 'QueriesCtrl',
      reloadOnSearch: false
    });
    $routeProvider.when('/queries/new', {
      templateUrl: '/views/query.html',
      controller: 'QuerySourceCtrl',
      reloadOnSearch: false,
      resolve: {
        'query': [
          'Query',
          function newQuery(Query) {
            return Query.newQuery();
          }
        ]
      }
    });
    $routeProvider.when('/queries/search', {
      templateUrl: '/views/queries_search_results.html',
      controller: 'QuerySearchCtrl',
      reloadOnSearch: true
    });
    $routeProvider.when('/queries/:queryId', {
      templateUrl: '/views/query.html',
      controller: 'QueryViewCtrl',
      reloadOnSearch: false,
      resolve: {
        'query': [
          'Query',
          '$route',
          getQuery
        ]
      }
    });
    $routeProvider.when('/queries/:queryId/source', {
      templateUrl: '/views/query.html',
      controller: 'QuerySourceCtrl',
      reloadOnSearch: false,
      resolve: {
        'query': [
          'Query',
          '$route',
          getQuery
        ]
      }
    });
    $routeProvider.when('/admin/status', {
      templateUrl: '/views/admin_status.html',
      controller: 'AdminStatusCtrl'
    });
    $routeProvider.when('/alerts', {
      templateUrl: '/views/alerts/list.html',
      controller: 'AlertsCtrl'
    });
    $routeProvider.when('/alerts/:alertId', {
      templateUrl: '/views/alerts/edit.html',
      controller: 'AlertCtrl'
    });
    $routeProvider.when('/data_sources/:dataSourceId', {
      templateUrl: '/views/data_sources/edit.html',
      controller: 'DataSourceCtrl'
    });
    $routeProvider.when('/data_sources', {
      templateUrl: '/views/data_sources/list.html',
      controller: 'DataSourcesCtrl'
    });
    $routeProvider.when('/users/new', {
      templateUrl: '/views/users/new.html',
      controller: 'NewUserCtrl'
    });
    $routeProvider.when('/users/:userId', {
      templateUrl: '/views/users/show.html',
      reloadOnSearch: false,
      controller: 'UserCtrl'
    });
    $routeProvider.when('/users', {
      templateUrl: '/views/users/list.html',
      controller: 'UsersCtrl'
    });
    $routeProvider.when('/', {
      templateUrl: '/views/personal.html',
      controller: 'PersonalIndexCtrl'
    });
    $routeProvider.when('/personal', {
      templateUrl: '/views/personal.html',
      controller: 'PersonalIndexCtrl'
    });
    $routeProvider.otherwise({ redirectTo: '/' });
  }
]);
(function () {
  'use strict';
  function KeyboardShortcuts() {
    this.bind = function bind(keymap) {
      _.forEach(keymap, function (fn, key) {
        Mousetrap.bindGlobal(key, function (e) {
          e.preventDefault();
          fn();
        });
      });
    };
    this.unbind = function unbind(keymap) {
      _.forEach(keymap, function (fn, key) {
        Mousetrap.unbind(key);
      });
    };
  }
  function Events($http) {
    this.events = [];
    this.post = _.debounce(function () {
      var events = this.events;
      this.events = [];
      $http.post('/api/events', events);
    }, 1000);
    this.record = function (user, action, object_type, object_id, additional_properties) {
      var event = {
          'user_id': user.id,
          'action': action,
          'object_type': object_type,
          'object_id': object_id,
          'timestamp': Date.now() / 1000
        };
      _.extend(event, additional_properties);
      this.events.push(event);
      this.post();
    };
  }
  angular.module('redash.services', []).service('KeyboardShortcuts', [KeyboardShortcuts]).service('Events', [
    '$http',
    Events
  ]);
}());
(function () {
  function QueryResultError(errorMessage) {
    this.errorMessage = errorMessage;
  }
  QueryResultError.prototype.getError = function () {
    return this.errorMessage;
  };
  QueryResultError.prototype.getStatus = function () {
    return 'failed';
  };
  QueryResultError.prototype.getData = function () {
    return null;
  };
  QueryResultError.prototype.getLog = function () {
    return null;
  };
  QueryResultError.prototype.getChartData = function () {
    return null;
  };
  var QueryResult = function ($resource, $timeout, $q) {
    var QueryResultResource = $resource('/api/query_results/:id', { id: '@id' }, { 'post': { 'method': 'POST' } });
    var Job = $resource('/api/jobs/:id', { id: '@id' });
    var updateFunction = function (props) {
      angular.extend(this, props);
      if ('query_result' in props) {
        this.status = 'done';
        this.filters = undefined;
        this.filterFreeze = undefined;
        var columnTypes = {};
        // TODO: we should stop manipulating incoming data, and switch to relaying on the column type set by the backend.
        // This logic is prone to errors, and better be removed. Kept for now, for backward compatability.
        _.each(this.query_result.data.rows, function (row) {
          _.each(row, function (v, k) {
            if (angular.isNumber(v)) {
              columnTypes[k] = 'float';
            } else if (_.isString(v) && v.match(/^\d{4}-\d{2}-\d{2}T/)) {
              row[k] = moment(v);
              columnTypes[k] = 'datetime';
            } else if (_.isString(v) && v.match(/^\d{4}-\d{2}-\d{2}/)) {
              row[k] = moment(v);
              columnTypes[k] = 'date';
            } else if (typeof v == 'object' && v !== null) {
              row[k] = JSON.stringify(v);
            }
          }, this);
        }, this);
        _.each(this.query_result.data.columns, function (column) {
          if (columnTypes[column.name]) {
            if (column.type == null || column.type == 'string') {
              column.type = columnTypes[column.name];
            }
          }
        });
        this.deferred.resolve(this);
      } else if (this.job.status == 3) {
        this.status = 'processing';
      } else {
        this.status = undefined;
      }
    };
    function QueryResult(props) {
      this.deferred = $q.defer();
      this.job = {};
      this.query_result = {};
      this.status = 'waiting';
      this.filters = undefined;
      this.filterFreeze = undefined;
      this.updatedAt = moment();
      if (props) {
        updateFunction.apply(this, [props]);
      }
    }
    var statuses = {
        1: 'waiting',
        2: 'processing',
        3: 'done',
        4: 'failed'
      };
    QueryResult.prototype.update = updateFunction;
    QueryResult.prototype.getId = function () {
      var id = null;
      if ('query_result' in this) {
        id = this.query_result.id;
      }
      return id;
    };
    QueryResult.prototype.cancelExecution = function () {
      Job.delete({ id: this.job.id });
    };
    QueryResult.prototype.getStatus = function () {
      return this.status || statuses[this.job.status];
    };
    QueryResult.prototype.getError = function () {
      // TODO: move this logic to the server...
      if (this.job.error == 'None') {
        return undefined;
      }
      return this.job.error;
    };
    QueryResult.prototype.getLog = function () {
      if (!this.query_result.data || !this.query_result.data.log || this.query_result.data.log.length == 0) {
        return null;
      }
      return this.query_result.data.log;
    };
    QueryResult.prototype.getUpdatedAt = function () {
      return this.query_result.retrieved_at || this.job.updated_at * 1000 || this.updatedAt;
    };
    QueryResult.prototype.getRuntime = function () {
      return this.query_result.runtime;
    };
    QueryResult.prototype.getRawData = function () {
      if (!this.query_result.data) {
        return null;
      }
      var data = this.query_result.data.rows;
      return data;
    };
    QueryResult.prototype.getData = function () {
      if (!this.query_result.data) {
        return null;
      }
      var filterValues = function (filters) {
        if (!filters) {
          return null;
        }
        return _.reduce(filters, function (str, filter) {
          return str + filter.current;
        }, '');
      };
      var filters = this.getFilters();
      var filterFreeze = filterValues(filters);
      if (this.filterFreeze != filterFreeze) {
        this.filterFreeze = filterFreeze;
        if (filters) {
          this.filteredData = _.filter(this.query_result.data.rows, function (row) {
            return _.reduce(filters, function (memo, filter) {
              if (!_.isArray(filter.current)) {
                filter.current = [filter.current];
              }
              ;
              return memo && _.some(filter.current, function (v) {
                // We compare with either the value or the String representation of the value,
                // because Select2 casts true/false to "true"/"false".
                return v == row[filter.name] || String(row[filter.name]) == v;
              });
            }, true);
          });
        } else {
          this.filteredData = this.query_result.data.rows;
        }
      }
      return this.filteredData;
    };
    QueryResult.prototype.getChartData = function (mapping) {
      var series = {};
      _.each(this.getData(), function (row) {
        var point = {};
        var seriesName = undefined;
        var xValue = 0;
        var yValues = {};
        _.each(row, function (value, definition) {
          var name = definition.split('::')[0] || definition.split('__')[0];
          var type = definition.split('::')[1] || definition.split('__')[0];
          if (mapping) {
            type = mapping[definition];
          }
          if (type == 'unused') {
            return;
          }
          if (type == 'x') {
            xValue = value;
            point[type] = value;
          }
          if (type == 'y') {
            if (value == null) {
              value = 0;
            }
            yValues[name] = value;
            point[type] = value;
          }
          if (type == 'series') {
            seriesName = String(value);
          }
          if (type == 'multiFilter' || type == 'multi-filter') {
            seriesName = String(value);
          }
        });
        var addPointToSeries = function (seriesName, point) {
          if (series[seriesName] == undefined) {
            series[seriesName] = {
              name: seriesName,
              type: 'column',
              data: []
            };
          }
          series[seriesName]['data'].push(point);
        };
        if (seriesName === undefined) {
          _.each(yValues, function (yValue, seriesName) {
            addPointToSeries(seriesName, {
              'x': xValue,
              'y': yValue
            });
          });
        } else {
          addPointToSeries(seriesName, point);
        }
      });
      return _.values(series);
    };
    QueryResult.prototype.getColumns = function () {
      if (this.columns == undefined && this.query_result.data) {
        this.columns = this.query_result.data.columns;
      }
      return this.columns;
    };
    QueryResult.prototype.getColumnNames = function () {
      if (this.columnNames == undefined && this.query_result.data) {
        this.columnNames = _.map(this.query_result.data.columns, function (v) {
          return v.name;
        });
      }
      return this.columnNames;
    };
    QueryResult.prototype.getColumnNameWithoutType = function (column) {
      var typeSplit;
      if (column.indexOf('::') != -1) {
        typeSplit = '::';
      } else if (column.indexOf('__' != -1)) {
        typeSplit = '__';
      } else {
        return column;
      }
      var parts = column.split(typeSplit);
      if (parts[0] == '' && parts.length == 2) {
        return parts[1];
      }
      return parts[0];
    };
    QueryResult.prototype.getColumnCleanName = function (column) {
      var name = this.getColumnNameWithoutType(column);
      return name;
    };
    QueryResult.prototype.getColumnFriendlyName = function (column) {
      return this.getColumnNameWithoutType(column).replace(/(?:^|\s)\S/g, function (a) {
        return a.toUpperCase();
      });
    };
    QueryResult.prototype.getColumnCleanNames = function () {
      return _.map(this.getColumnNames(), function (col) {
        return this.getColumnCleanName(col);
      }, this);
    };
    QueryResult.prototype.getColumnFriendlyNames = function () {
      return _.map(this.getColumnNames(), function (col) {
        return this.getColumnFriendlyName(col);
      }, this);
    };
    QueryResult.prototype.getFilters = function () {
      if (!this.filters) {
        this.prepareFilters();
      }
      return this.filters;
    };
    QueryResult.prototype.prepareFilters = function () {
      var filters = [];
      var filterTypes = [
          'filter',
          'multi-filter',
          'multiFilter'
        ];
      _.each(this.getColumnNames(), function (col) {
        var type = col.split('::')[1] || col.split('__')[1];
        if (_.contains(filterTypes, type)) {
          // filter found
          var filter = {
              name: col,
              friendlyName: this.getColumnFriendlyName(col),
              values: [],
              multiple: type == 'multiFilter' || type == 'multi-filter'
            };
          filters.push(filter);
        }
      }, this);
      _.each(this.getRawData(), function (row) {
        _.each(filters, function (filter) {
          filter.values.push(row[filter.name]);
          if (filter.values.length == 1) {
            filter.current = row[filter.name];
          }
        });
      });
      _.each(filters, function (filter) {
        filter.values = _.uniq(filter.values);
      });
      this.filters = filters;
    };
    var refreshStatus = function (queryResult, query) {
      Job.get({ 'id': queryResult.job.id }, function (response) {
        queryResult.update(response);
        if (queryResult.getStatus() == 'processing' && queryResult.job.query_result_id && queryResult.job.query_result_id != 'None') {
          QueryResultResource.get({ 'id': queryResult.job.query_result_id }, function (response) {
            queryResult.update(response);
          });
        } else if (queryResult.getStatus() != 'failed') {
          $timeout(function () {
            refreshStatus(queryResult, query);
          }, 3000);
        }
      });
    };
    QueryResult.getById = function (id) {
      var queryResult = new QueryResult();
      QueryResultResource.get({ 'id': id }, function (response) {
        queryResult.update(response);
      });
      return queryResult;
    };
    QueryResult.prototype.toPromise = function () {
      return this.deferred.promise;
    };
    QueryResult.get = function (data_source_id, query, maxAge, queryId) {
      var queryResult = new QueryResult();
      var params = {
          'data_source_id': data_source_id,
          'query': query,
          'max_age': maxAge
        };
      if (queryId !== undefined) {
        params['query_id'] = queryId;
      }
      ;
      QueryResultResource.post(params, function (response) {
        queryResult.update(response);
        if ('job' in response) {
          refreshStatus(queryResult, query);
        }
      });
      return queryResult;
    };
    return QueryResult;
  };
  var Query = function ($resource, QueryResult, DataSource) {
    var Query = $resource('/api/queries/:id', { id: '@id' }, {
        search: {
          method: 'get',
          isArray: true,
          url: '/api/queries/search'
        },
        recent: {
          method: 'get',
          isArray: true,
          url: '/api/queries/recent'
        }
      });
    Query.newQuery = function () {
      return new Query({
        query: '',
        name: 'New Query',
        schedule: null,
        user: currentUser
      });
    };
    Query.collectParamsFromQueryString = function ($location, query) {
      var parameterNames = query.getParameters();
      var parameters = {};
      var queryString = $location.search();
      _.each(parameterNames, function (param, i) {
        var qsName = 'p_' + param;
        if (qsName in queryString) {
          parameters[param] = queryString[qsName];
        }
      });
      return parameters;
    };
    Query.prototype.getSourceLink = function () {
      return '/queries/' + this.id + '/source';
    };
    Query.prototype.isNew = function () {
      return this.id === undefined;
    };
    Query.prototype.hasDailySchedule = function () {
      return this.schedule && this.schedule.match(/\d\d:\d\d/) !== null;
    };
    Query.prototype.scheduleInLocalTime = function () {
      var parts = this.schedule.split(':');
      return moment.utc().hour(parts[0]).minute(parts[1]).local().format('HH:mm');
    };
    Query.prototype.getQueryResult = function (maxAge, parameters) {
      if (!this.query) {
        return;
      }
      var queryText = this.query;
      var queryParameters = this.getParameters();
      var paramsRequired = !_.isEmpty(queryParameters);
      var missingParams = parameters === undefined ? queryParameters : _.difference(queryParameters, _.keys(parameters));
      if (paramsRequired && missingParams.length > 0) {
        var paramsWord = 'parameter';
        if (missingParams.length > 1) {
          paramsWord = 'parameters';
        }
        return new QueryResult({
          job: {
            error: 'Missing values for ' + missingParams.join(', ') + ' ' + paramsWord + '.',
            status: 4
          }
        });
      }
      if (paramsRequired) {
        queryText = Mustache.render(queryText, parameters);
        // Need to clear latest results, to make sure we don't used results for different params.
        this.latest_query_data = null;
        this.latest_query_data_id = null;
      }
      if (this.latest_query_data && maxAge != 0) {
        if (!this.queryResult) {
          this.queryResult = new QueryResult({ 'query_result': this.latest_query_data });
        }
      } else if (this.latest_query_data_id && maxAge != 0) {
        if (!this.queryResult) {
          this.queryResult = QueryResult.getById(this.latest_query_data_id);
        }
      } else if (this.data_source_id) {
        this.queryResult = QueryResult.get(this.data_source_id, queryText, maxAge, this.id);
      } else {
        return new QueryResultError('Please select data source to run this query.');
      }
      return this.queryResult;
    };
    Query.prototype.getQueryResultPromise = function () {
      return this.getQueryResult().toPromise();
    };
    Query.prototype.getParameters = function () {
      var parts = Mustache.parse(this.query);
      var parameters = [];
      var collectParams = function (parts) {
        parameters = [];
        _.each(parts, function (part) {
          if (part[0] == 'name' || part[0] == '&') {
            parameters.push(part[1]);
          } else if (part[0] == '#') {
            parameters = _.union(parameters, collectParams(part[4]));
          }
        });
        return parameters;
      };
      parameters = collectParams(parts);
      return parameters;
    };
    return Query;
  };
  var DataSource = function ($resource) {
    var actions = {
        'get': {
          'method': 'GET',
          'cache': false,
          'isArray': false
        },
        'query': {
          'method': 'GET',
          'cache': false,
          'isArray': true
        },
        'getSchema': {
          'method': 'GET',
          'cache': true,
          'isArray': true,
          'url': '/api/data_sources/:id/schema'
        }
      };
    var DataSourceResource = $resource('/api/data_sources/:id', { id: '@id' }, actions);
    return DataSourceResource;
  };
  var User = function ($resource, $http) {
    var transformSingle = function (user) {
      if (user.groups !== undefined) {
        user.admin = user.groups.indexOf('admin') != -1;
      }
    };
    var transform = $http.defaults.transformResponse.concat(function (data, headers) {
        if (_.isArray(data)) {
          _.each(data, transformSingle);
        } else {
          transformSingle(data);
        }
        return data;
      });
    var actions = {
        'get': {
          method: 'GET',
          transformResponse: transform
        },
        'save': {
          method: 'POST',
          transformResponse: transform
        },
        'query': {
          method: 'GET',
          isArray: true,
          transformResponse: transform
        },
        'delete': {
          method: 'DELETE',
          transformResponse: transform
        }
      };
    var UserResource = $resource('/api/users/:id', { id: '@id' }, actions);
    return UserResource;
  };
  var AlertSubscription = function ($resource) {
    var resource = $resource('/api/alerts/:alertId/subscriptions/:userId', {
        alertId: '@alert_id',
        userId: '@user.id'
      });
    return resource;
  };
  var Alert = function ($resource, $http) {
    var actions = {
        save: {
          method: 'POST',
          transformRequest: [function (data) {
              var newData = _.extend({}, data);
              if (newData.query_id === undefined) {
                newData.query_id = newData.query.id;
                delete newData.query;
              }
              return newData;
            }].concat($http.defaults.transformRequest)
        }
      };
    var resource = $resource('/api/alerts/:id', { id: '@id' }, actions);
    return resource;
  };
  var Widget = function ($resource, Query) {
    var WidgetResource = $resource('/api/widgets/:id', { id: '@id' });
    WidgetResource.prototype.getQuery = function () {
      if (!this.query && this.visualization) {
        this.query = new Query(this.visualization.query);
      }
      return this.query;
    };
    WidgetResource.prototype.getName = function () {
      if (this.visualization) {
        return this.visualization.query.name + ' (' + this.visualization.name + ')';
      }
      return _.str.truncate(this.text, 20);
    };
    return WidgetResource;
  };
  angular.module('redash.services').factory('QueryResult', [
    '$resource',
    '$timeout',
    '$q',
    QueryResult
  ]).factory('Query', [
    '$resource',
    'QueryResult',
    'DataSource',
    Query
  ]).factory('DataSource', [
    '$resource',
    DataSource
  ]).factory('Alert', [
    '$resource',
    '$http',
    Alert
  ]).factory('AlertSubscription', [
    '$resource',
    AlertSubscription
  ]).factory('Widget', [
    '$resource',
    'Query',
    Widget
  ]).factory('User', [
    '$resource',
    '$http',
    User
  ]);
}());
(function () {
  var notifications = function (Events) {
    var notificationService = {};
    notificationService.isSupported = function () {
      if ('Notification' in window) {
        return true;
      } else {
        console.log('HTML5 notifications are not supported.');
        return false;
      }
    };
    notificationService.getPermissions = function () {
      if (!this.isSupported()) {
        return;
      }
      if (Notification.permission !== 'granted') {
        Notification.requestPermission(function (status) {
          if (Notification.permission !== status) {
            Notification.permission = status;
          }
        });
      }
    };
    notificationService.showNotification = function (title, content) {
      if (!this.isSupported()) {
        return;
      }
      //using the 'tag' to avoid showing duplicate notifications
      var notification = new Notification(title, {
          'tag': title + content,
          'body': content
        });
      setTimeout(function () {
        notification.close();
      }, 3000);
      notification.onclick = function () {
        window.focus();
        this.cancel();
        Events.record(currentUser, 'click', 'notification');
      };
    };
    return notificationService;
  };
  angular.module('redash.services').factory('notifications', [
    'Events',
    notifications
  ]);
}());
(function () {
  var Dashboard = function ($resource) {
    var resource = $resource('/api/dashboards/:slug', { slug: '@slug' }, {
        recent: {
          method: 'get',
          isArray: true,
          url: '/api/dashboards/recent'
        }
      });
    resource.prototype.canEdit = function () {
      return currentUser.hasPermission('admin') || currentUser.canEdit(this);
    };
    return resource;
  };
  angular.module('redash.services').factory('Dashboard', [
    '$resource',
    Dashboard
  ]);
}());
(function () {
  var dateFormatter = function (value) {
    if (!value) {
      return '-';
    }
    return value.toDate().toLocaleString();
  };
  var QuerySearchCtrl = function ($scope, $location, $filter, Events, Query) {
    $scope.$parent.pageTitle = 'Queries Search';
    $scope.gridConfig = {
      isPaginationEnabled: true,
      itemsByPage: 50,
      maxSize: 8
    };
    $scope.gridColumns = [
      {
        'label': 'Name',
        'map': 'name',
        'cellTemplateUrl': '/views/queries_query_name_cell.html'
      },
      {
        'label': 'Created By',
        'map': 'user.name'
      },
      {
        'label': 'Created At',
        'map': 'created_at',
        'formatFunction': dateFormatter
      },
      {
        'label': 'Update Schedule',
        'map': 'schedule',
        'formatFunction': function (value) {
          return $filter('scheduleHumanize')(value);
        }
      }
    ];
    $scope.queries = [];
    $scope.$parent.term = $location.search().q;
    Query.search({ q: $scope.term }, function (results) {
      $scope.queries = _.map(results, function (query) {
        query.created_at = moment(query.created_at);
        return query;
      });
    });
    $scope.search = function () {
      if (!angular.isString($scope.term) || $scope.term.trim() == '') {
        $scope.queries = [];
        return;
      }
      $location.search({ q: $scope.term });
    };
    Events.record(currentUser, 'search', 'query', '', { 'term': $scope.term });
  };
  var QueriesCtrl = function ($scope, $http, $location, $filter, Query) {
    $scope.$parent.pageTitle = 'All Queries';
    $scope.gridConfig = {
      isPaginationEnabled: true,
      itemsByPage: 50,
      maxSize: 8,
      isGlobalSearchActivated: true
    };
    $scope.allQueries = [];
    $scope.queries = [];
    var filterQueries = function () {
      $scope.queries = _.filter($scope.allQueries, function (query) {
        if (!$scope.selectedTab) {
          return false;
        }
        if ($scope.selectedTab.key == 'my') {
          return query.user.id == currentUser.id && query.name != 'New Query';
        } else if ($scope.selectedTab.key == 'drafts') {
          return query.user.id == currentUser.id && query.name == 'New Query';
        }
        return query.name != 'New Query';
      });
    };
    Query.query(function (queries) {
      $scope.allQueries = _.map(queries, function (query) {
        query.created_at = moment(query.created_at);
        query.retrieved_at = moment(query.retrieved_at);
        return query;
      });
      filterQueries();
    });
    $scope.gridColumns = [
      {
        'label': 'Name',
        'map': 'name',
        'cellTemplateUrl': '/views/queries_query_name_cell.html'
      },
      {
        'label': 'Created By',
        'map': 'user.name'
      },
      {
        'label': 'Created At',
        'map': 'created_at',
        'formatFunction': dateFormatter
      },
      {
        'label': 'Runtime',
        'map': 'runtime',
        'formatFunction': function (value) {
          return $filter('durationHumanize')(value);
        }
      },
      {
        'label': 'Last Executed At',
        'map': 'retrieved_at',
        'formatFunction': dateFormatter
      },
      {
        'label': 'Update Schedule',
        'map': 'schedule',
        'formatFunction': function (value) {
          return $filter('scheduleHumanize')(value);
        }
      }
    ];
    $scope.tabs = [
      {
        'name': 'My Queries',
        'key': 'my'
      },
      {
        'key': 'all',
        'name': 'All Queries'
      },
      {
        'key': 'drafts',
        'name': 'Drafts'
      }
    ];
    $scope.$watch('selectedTab', function (tab) {
      if (tab) {
        $scope.$parent.pageTitle = tab.name;
      }
      filterQueries();
    });
  };
  var MainCtrl = function ($scope, $location, Dashboard, notifications) {
    if (featureFlags.clientSideMetrics) {
      $scope.$on('$locationChangeSuccess', function (event, newLocation, oldLocation) {
        // This will be called once per actual page load.
        Bucky.sendPagePerformance();
      });
    }
    $scope.dashboards = [];
    $scope.reloadDashboards = function () {
      Dashboard.query(function (dashboards) {
        $scope.dashboards = _.sortBy(dashboards, 'name');
        $scope.allDashboards = _.groupBy($scope.dashboards, function (d) {
          parts = d.name.split(':');
          if (parts.length == 1) {
            return 'Other';
          }
          return parts[0];
        });
        $scope.otherDashboards = $scope.allDashboards['Other'] || [];
        $scope.groupedDashboards = _.omit($scope.allDashboards, 'Other');
      });
    };
    $scope.searchQueries = function () {
      $location.path('/queries/search').search({ q: $scope.term });
    };
    $scope.reloadDashboards();
    $scope.currentUser = currentUser;
    $scope.newDashboard = {
      'name': null,
      'layout': null
    };
    $(window).click(function () {
      notifications.getPermissions();
    });
  };
  var IndexCtrl = function ($scope, Events, Dashboard) {
    Events.record(currentUser, 'view', 'page', 'homepage');
    $scope.$parent.pageTitle = 'Home';
  };
  var PersonalIndexCtrl = function ($scope, Events, Dashboard, Query) {
    Events.record(currentUser, 'view', 'page', 'personal_homepage');
    $scope.$parent.pageTitle = 'Home';
    $scope.recentQueries = Query.recent();
    $scope.recentDashboards = Dashboard.recent();
  };
  angular.module('redash.controllers', []).controller('QueriesCtrl', [
    '$scope',
    '$http',
    '$location',
    '$filter',
    'Query',
    QueriesCtrl
  ]).controller('IndexCtrl', [
    '$scope',
    'Events',
    'Dashboard',
    IndexCtrl
  ]).controller('PersonalIndexCtrl', [
    '$scope',
    'Events',
    'Dashboard',
    'Query',
    PersonalIndexCtrl
  ]).controller('MainCtrl', [
    '$scope',
    '$location',
    'Dashboard',
    'notifications',
    MainCtrl
  ]).controller('QuerySearchCtrl', [
    '$scope',
    '$location',
    '$filter',
    'Events',
    'Query',
    QuerySearchCtrl
  ]);
}());
(function () {
  var DashboardCtrl = function ($scope, Events, Widget, $routeParams, $location, $http, $timeout, $q, Dashboard) {
    $scope.refreshEnabled = false;
    $scope.refreshRate = 60;
    var loadDashboard = _.throttle(function () {
        $scope.dashboard = Dashboard.get({ slug: $routeParams.dashboardSlug }, function (dashboard) {
          Events.record(currentUser, 'view', 'dashboard', dashboard.id);
          $scope.$parent.pageTitle = dashboard.name;
          var promises = [];
          $scope.dashboard.widgets = _.map($scope.dashboard.widgets, function (row) {
            return _.map(row, function (widget) {
              var w = new Widget(widget);
              if (w.visualization) {
                promises.push(w.getQuery().getQueryResult().toPromise());
              }
              return w;
            });
          });
          $q.all(promises).then(function (queryResults) {
            var filters = {};
            _.each(queryResults, function (queryResult) {
              var queryFilters = queryResult.getFilters();
              _.each(queryFilters, function (queryFilter) {
                var hasQueryStringValue = _.has($location.search(), queryFilter.name);
                if (!(hasQueryStringValue || dashboard.dashboard_filters_enabled)) {
                  // If dashboard filters not enabled, or no query string value given, skip filters linking.
                  return;
                }
                if (!_.has(filters, queryFilter.name)) {
                  var filter = _.extend({}, queryFilter);
                  filters[filter.name] = filter;
                  filters[filter.name].originFilters = [];
                  if (hasQueryStringValue) {
                    filter.current = $location.search()[filter.name];
                  }
                  $scope.$watch(function () {
                    return filter.current;
                  }, function (value) {
                    _.each(filter.originFilters, function (originFilter) {
                      originFilter.current = value;
                    });
                  });
                }
                // TODO: merge values.
                filters[queryFilter.name].originFilters.push(queryFilter);
              });
            });
            $scope.filters = _.values(filters);
          });
        }, function () {
          // error...
          // try again. we wrap loadDashboard with throttle so it doesn't happen too often.\
          // we might want to consider exponential backoff and also move this as a general solution in $http/$resource for
          // all AJAX calls.
          loadDashboard();
        });
      }, 1000);
    loadDashboard();
    var autoRefresh = function () {
      if ($scope.refreshEnabled) {
        $timeout(function () {
          Dashboard.get({ slug: $routeParams.dashboardSlug }, function (dashboard) {
            var newWidgets = _.groupBy(_.flatten(dashboard.widgets), 'id');
            _.each($scope.dashboard.widgets, function (row) {
              _.each(row, function (widget, i) {
                var newWidget = newWidgets[widget.id];
                if (newWidget && newWidget[0].visualization.query.latest_query_data_id != widget.visualization.query.latest_query_data_id) {
                  row[i] = new Widget(newWidget[0]);
                }
              });
            });
            autoRefresh();
          });
        }, $scope.refreshRate);
      }
    };
    $scope.archiveDashboard = function () {
      if (confirm('Are you sure you want to archive the "' + $scope.dashboard.name + '" dashboard?')) {
        Events.record(currentUser, 'archive', 'dashboard', $scope.dashboard.id);
        $scope.dashboard.$delete(function () {
          $scope.$parent.reloadDashboards();
        });
      }
    };
    $scope.triggerRefresh = function () {
      $scope.refreshEnabled = !$scope.refreshEnabled;
      Events.record(currentUser, 'autorefresh', 'dashboard', dashboard.id, { 'enable': $scope.refreshEnabled });
      if ($scope.refreshEnabled) {
        var refreshRate = _.min(_.map(_.flatten($scope.dashboard.widgets), function (widget) {
            var schedule = widget.visualization.query.schedule;
            if (schedule === null || schedule.match(/\d\d:\d\d/) !== null) {
              return 60;
            }
            return widget.visualization.query.schedule;
          }));
        $scope.refreshRate = _.max([
          120,
          refreshRate * 2
        ]) * 1000;
        autoRefresh();
      }
    };
  };
  var WidgetCtrl = function ($scope, $location, Events, Query) {
    $scope.deleteWidget = function () {
      if (!confirm('Are you sure you want to remove "' + $scope.widget.getName() + '" from the dashboard?')) {
        return;
      }
      Events.record(currentUser, 'delete', 'widget', $scope.widget.id);
      $scope.widget.$delete(function () {
        $scope.dashboard.widgets = _.map($scope.dashboard.widgets, function (row) {
          return _.filter(row, function (widget) {
            return widget.id != undefined;
          });
        });
      });
    };
    Events.record(currentUser, 'view', 'widget', $scope.widget.id);
    if ($scope.widget.visualization) {
      Events.record(currentUser, 'view', 'query', $scope.widget.visualization.query.id);
      Events.record(currentUser, 'view', 'visualization', $scope.widget.visualization.id);
      $scope.query = $scope.widget.getQuery();
      var parameters = Query.collectParamsFromQueryString($location, $scope.query);
      var maxAge = $location.search()['maxAge'];
      $scope.queryResult = $scope.query.getQueryResult(maxAge, parameters);
      $scope.type = 'visualization';
    } else {
      $scope.type = 'textbox';
    }
  };
  angular.module('redash.controllers').controller('DashboardCtrl', [
    '$scope',
    'Events',
    'Widget',
    '$routeParams',
    '$location',
    '$http',
    '$timeout',
    '$q',
    'Dashboard',
    DashboardCtrl
  ]).controller('WidgetCtrl', [
    '$scope',
    '$location',
    'Events',
    'Query',
    WidgetCtrl
  ]);
}());
(function () {
  var AdminStatusCtrl = function ($scope, Events, $http, $timeout) {
    Events.record(currentUser, 'view', 'page', 'admin/status');
    $scope.$parent.pageTitle = 'System Status';
    var refresh = function () {
      $scope.refresh_time = moment().add('minutes', 1);
      $http.get('/status.json').success(function (data) {
        $scope.workers = data.workers;
        delete data.workers;
        $scope.manager = data.manager;
        delete data.manager;
        $scope.status = data;
      });
      $timeout(refresh, 59 * 1000);
    };
    refresh();
  };
  angular.module('redash.admin_controllers', []).controller('AdminStatusCtrl', [
    '$scope',
    'Events',
    '$http',
    '$timeout',
    AdminStatusCtrl
  ]);
}());
(function () {
  var DataSourcesCtrl = function ($scope, $location, growl, Events, DataSource) {
    Events.record(currentUser, 'view', 'page', 'admin/data_sources');
    $scope.$parent.pageTitle = 'Data Sources';
    $scope.dataSources = DataSource.query();
    $scope.openDataSource = function (datasource) {
      $location.path('/data_sources/' + datasource.id);
    };
    $scope.deleteDataSource = function (event, datasource) {
      event.stopPropagation();
      Events.record(currentUser, 'delete', 'datasource', datasource.id);
      datasource.$delete(function (resource) {
        growl.addSuccessMessage('Data source deleted succesfully.');
        this.$parent.dataSources = _.without(this.dataSources, resource);
      }.bind(this), function (httpResponse) {
        console.log('Failed to delete data source: ', httpResponse.status, httpResponse.statusText, httpResponse.data);
        growl.addErrorMessage('Failed to delete data source.');
      });
    };
  };
  var DataSourceCtrl = function ($scope, $routeParams, $http, $location, Events, DataSource) {
    Events.record(currentUser, 'view', 'page', 'admin/data_source');
    $scope.$parent.pageTitle = 'Data Sources';
    $scope.dataSourceId = $routeParams.dataSourceId;
    if ($scope.dataSourceId == 'new') {
      $scope.dataSource = new DataSource({ options: {} });
    } else {
      $scope.dataSource = DataSource.get({ id: $routeParams.dataSourceId });
    }
    $scope.$watch('dataSource.id', function (id) {
      if (id != $scope.dataSourceId && id !== undefined) {
        $location.path('/data_sources/' + id).replace();
      }
    });
  };
  angular.module('redash.controllers').controller('DataSourcesCtrl', [
    '$scope',
    '$location',
    'growl',
    'Events',
    'DataSource',
    DataSourcesCtrl
  ]).controller('DataSourceCtrl', [
    '$scope',
    '$routeParams',
    '$http',
    '$location',
    'Events',
    'DataSource',
    DataSourceCtrl
  ]);
}());
(function () {
  'use strict';
  function QueryViewCtrl($scope, Events, $route, $location, notifications, growl, $modal, Query, DataSource) {
    var DEFAULT_TAB = 'table';
    var getQueryResult = function (maxAge) {
      // Collect params, and getQueryResult with params; getQueryResult merges it into the query
      var parameters = Query.collectParamsFromQueryString($location, $scope.query);
      if (maxAge == undefined) {
        maxAge = $location.search()['maxAge'];
      }
      if (maxAge == undefined) {
        maxAge = -1;
      }
      $scope.showLog = false;
      $scope.queryResult = $scope.query.getQueryResult(maxAge, parameters);
    };
    $scope.dataSource = {};
    $scope.query = $route.current.locals.query;
    var updateSchema = function () {
      $scope.hasSchema = false;
      $scope.editorSize = 'col-md-12';
      var dataSourceId = $scope.query.data_source_id || $scope.dataSources[0].id;
      DataSource.getSchema({ id: dataSourceId }, function (data) {
        if (data && data.length > 0) {
          $scope.schema = data;
          _.each(data, function (table) {
            table.collapsed = true;
          });
          $scope.editorSize = 'col-md-9';
          $scope.hasSchema = true;
        } else {
          $scope.hasSchema = false;
          $scope.editorSize = 'col-md-12';
        }
      });
    };
    Events.record(currentUser, 'view', 'query', $scope.query.id);
    getQueryResult();
    $scope.queryExecuting = false;
    $scope.isQueryOwner = currentUser.id === $scope.query.user.id || currentUser.hasPermission('admin');
    $scope.canViewSource = currentUser.hasPermission('view_source');
    $scope.dataSources = DataSource.query(function (dataSources) {
      updateSchema();
      if ($scope.query.isNew()) {
        $scope.query.data_source_id = $scope.query.data_source_id || dataSources[0].id;
        $scope.dataSource = _.find(dataSources, function (ds) {
          return ds.id == $scope.query.data_source_id;
        });
      }
    });
    // in view mode, latest dataset is always visible
    // source mode changes this behavior
    $scope.showDataset = true;
    $scope.showLog = false;
    $scope.lockButton = function (lock) {
      $scope.queryExecuting = lock;
    };
    $scope.showApiKey = function () {
      alert('API Key for this query:\n' + $scope.query.api_key);
    };
    $scope.saveQuery = function (options, data) {
      if (data) {
        data.id = $scope.query.id;
      } else {
        data = _.clone($scope.query);
      }
      options = _.extend({}, {
        successMessage: 'Query saved',
        errorMessage: 'Query could not be saved'
      }, options);
      delete data.latest_query_data;
      delete data.queryResult;
      return Query.save(data, function () {
        growl.addSuccessMessage(options.successMessage);
      }, function (httpResponse) {
        growl.addErrorMessage(options.errorMessage);
      }).$promise;
    };
    $scope.saveDescription = function () {
      Events.record(currentUser, 'edit_description', 'query', $scope.query.id);
      $scope.saveQuery(undefined, { 'description': $scope.query.description });
    };
    $scope.saveName = function () {
      Events.record(currentUser, 'edit_name', 'query', $scope.query.id);
      $scope.saveQuery(undefined, { 'name': $scope.query.name });
    };
    $scope.executeQuery = function () {
      if (!$scope.query.query) {
        return;
      }
      getQueryResult(0);
      $scope.lockButton(true);
      $scope.cancelling = false;
      Events.record(currentUser, 'execute', 'query', $scope.query.id);
    };
    $scope.cancelExecution = function () {
      $scope.cancelling = true;
      $scope.queryResult.cancelExecution();
      Events.record(currentUser, 'cancel_execute', 'query', $scope.query.id);
    };
    $scope.archiveQuery = function (options, data) {
      if (data) {
        data.id = $scope.query.id;
      } else {
        data = $scope.query;
      }
      $scope.isDirty = false;
      options = _.extend({}, {
        successMessage: 'Query archived',
        errorMessage: 'Query could not be archived'
      }, options);
      return Query.delete({ id: data.id }, function () {
        $scope.query.is_archived = true;
        $scope.query.schedule = null;
        growl.addSuccessMessage(options.successMessage);
        // This feels dirty.
        $('#archive-confirmation-modal').modal('hide');
      }, function (httpResponse) {
        growl.addErrorMessage(options.errorMessage);
      }).$promise;
    };
    $scope.updateDataSource = function () {
      Events.record(currentUser, 'update_data_source', 'query', $scope.query.id);
      $scope.query.latest_query_data = null;
      $scope.query.latest_query_data_id = null;
      if ($scope.query.id) {
        Query.save({
          'id': $scope.query.id,
          'data_source_id': $scope.query.data_source_id,
          'latest_query_data_id': null
        });
      }
      updateSchema();
      $scope.dataSource = _.find($scope.dataSources, function (ds) {
        return ds.id == $scope.query.data_source_id;
      });
      $scope.executeQuery();
    };
    $scope.setVisualizationTab = function (visualization) {
      $scope.selectedTab = visualization.id;
      $location.hash(visualization.id);
    };
    $scope.$watch('query.name', function () {
      $scope.$parent.pageTitle = $scope.query.name;
    });
    $scope.$watch('queryResult && queryResult.getData()', function (data, oldData) {
      if (!data) {
        return;
      }
      $scope.filters = $scope.queryResult.getFilters();
    });
    $scope.$watch('queryResult && queryResult.getStatus()', function (status) {
      if (!status) {
        return;
      }
      if (status == 'done') {
        if ($scope.query.id && $scope.query.latest_query_data_id != $scope.queryResult.getId() && $scope.query.query_hash == $scope.queryResult.query_result.query_hash) {
          Query.save({
            'id': $scope.query.id,
            'latest_query_data_id': $scope.queryResult.getId()
          });
        }
        $scope.query.latest_query_data_id = $scope.queryResult.getId();
        $scope.query.queryResult = $scope.queryResult;
        notifications.showNotification('re:dash', $scope.query.name + ' updated.');
      } else if (status == 'failed') {
        notifications.showNotification('re:dash', $scope.query.name + ' failed to run: ' + $scope.queryResult.getError());
      }
      if (status === 'done' || status === 'failed') {
        $scope.lockButton(false);
      }
      if ($scope.queryResult.getLog() != null) {
        $scope.showLog = true;
      }
    });
    $scope.openScheduleForm = function () {
      if (!$scope.isQueryOwner) {
        return;
      }
      ;
      $modal.open({
        templateUrl: '/views/schedule_form.html',
        size: 'sm',
        scope: $scope,
        controller: [
          '$scope',
          '$modalInstance',
          function ($scope, $modalInstance) {
            $scope.close = function () {
              $modalInstance.close();
            };
            if ($scope.query.hasDailySchedule()) {
              $scope.refreshType = 'daily';
            } else {
              $scope.refreshType = 'periodic';
            }
          }
        ]
      });
    };
    $scope.$watch(function () {
      return $location.hash();
    }, function (hash) {
      if (hash == 'pivot') {
        Events.record(currentUser, 'pivot', 'query', $scope.query && $scope.query.id);
      }
      $scope.selectedTab = hash || DEFAULT_TAB;
    });
  }
  ;
  angular.module('redash.controllers').controller('QueryViewCtrl', [
    '$scope',
    'Events',
    '$route',
    '$location',
    'notifications',
    'growl',
    '$modal',
    'Query',
    'DataSource',
    QueryViewCtrl
  ]);
}());
(function () {
  'use strict';
  function QuerySourceCtrl(Events, growl, $controller, $scope, $location, Query, Visualization, KeyboardShortcuts) {
    // extends QueryViewCtrl
    $controller('QueryViewCtrl', { $scope: $scope });
    // TODO:
    // This doesn't get inherited. Setting it on this didn't work either (which is weird).
    // Obviously it shouldn't be repeated, but we got bigger fish to fry.
    var DEFAULT_TAB = 'table';
    Events.record(currentUser, 'view_source', 'query', $scope.query.id);
    var isNewQuery = !$scope.query.id, queryText = $scope.query.query,
      // ref to QueryViewCtrl.saveQuery
      saveQuery = $scope.saveQuery;
    $scope.sourceMode = true;
    $scope.canEdit = currentUser.canEdit($scope.query) || featureFlags.allowAllToEditQueries;
    $scope.isDirty = false;
    $scope.newVisualization = undefined;
    // @override
    Object.defineProperty($scope, 'showDataset', {
      get: function () {
        return $scope.queryResult && $scope.queryResult.getStatus() == 'done';
      }
    });
    var shortcuts = {
        'meta+s': function () {
          if ($scope.canEdit) {
            $scope.saveQuery();
          }
        },
        'ctrl+s': function () {
          if ($scope.canEdit) {
            $scope.saveQuery();
          }
        },
        'meta+enter': $scope.executeQuery,
        'ctrl+enter': $scope.executeQuery
      };
    KeyboardShortcuts.bind(shortcuts);
    // @override
    $scope.saveQuery = function (options, data) {
      var savePromise = saveQuery(options, data);
      savePromise.then(function (savedQuery) {
        queryText = savedQuery.query;
        $scope.isDirty = $scope.query.query !== queryText;
        if (isNewQuery) {
          // redirect to new created query (keep hash)
          $location.path(savedQuery.getSourceLink()).replace();
        }
      });
      return savePromise;
    };
    $scope.duplicateQuery = function () {
      Events.record(currentUser, 'fork', 'query', $scope.query.id);
      $scope.query.id = null;
      $scope.query.schedule = null;
      $scope.saveQuery({
        successMessage: 'Query forked',
        errorMessage: 'Query could not be forked'
      }).then(function redirect(savedQuery) {
        // redirect to forked query (clear hash)
        $location.url(savedQuery.getSourceLink()).replace();
      });
    };
    $scope.deleteVisualization = function ($e, vis) {
      $e.preventDefault();
      if (confirm('Are you sure you want to delete ' + vis.name + ' ?')) {
        Events.record(currentUser, 'delete', 'visualization', vis.id);
        Visualization.delete(vis, function () {
          if ($scope.selectedTab == vis.id) {
            $scope.selectedTab = DEFAULT_TAB;
            $location.hash($scope.selectedTab);
          }
          $scope.query.visualizations = $scope.query.visualizations.filter(function (v) {
            return vis.id !== v.id;
          });
        }, function () {
          growl.addErrorMessage('Error deleting visualization. Maybe it\'s used in a dashboard?');
        });
      }
    };
    $scope.$watch('query.query', function (newQueryText) {
      $scope.isDirty = newQueryText !== queryText;
    });
    $scope.$on('$destroy', function destroy() {
      KeyboardShortcuts.unbind(shortcuts);
    });
    if (isNewQuery) {
      // save new query when creating a visualization
      var unbind = $scope.$watch('selectedTab == "add"', function (triggerSave) {
          if (triggerSave) {
            unbind();
            $scope.saveQuery();
          }
        });
    }
  }
  angular.module('redash.controllers').controller('QuerySourceCtrl', [
    'Events',
    'growl',
    '$controller',
    '$scope',
    '$location',
    'Query',
    'Visualization',
    'KeyboardShortcuts',
    QuerySourceCtrl
  ]);
}());
(function () {
  var UsersCtrl = function ($scope, $location, growl, Events, User) {
    Events.record(currentUser, 'view', 'page', 'users');
    $scope.$parent.pageTitle = 'Users';
    $scope.gridConfig = {
      isPaginationEnabled: true,
      itemsByPage: 50,
      maxSize: 8
    };
    $scope.gridColumns = [
      {
        'label': '',
        'map': 'gravatar_url',
        'cellTemplate': '<img src="{{dataRow.gravatar_url}}" height="40px"/>'
      },
      {
        'label': 'Name',
        'map': 'name',
        'cellTemplate': '<a href="/users/{{dataRow.id}}">{{dataRow.name}}</a>'
      },
      {
        'label': 'Joined',
        'cellTemplate': '<span am-time-ago="dataRow.created_at"></span>'
      }
    ];
    $scope.users = [];
    User.query(function (users) {
      $scope.users = users;
    });
  };
  var UserCtrl = function ($scope, $routeParams, $http, $location, growl, Events, User) {
    $scope.$parent.pageTitle = 'Users';
    $scope.userId = $routeParams.userId;
    if ($scope.userId === 'me') {
      $scope.userId = currentUser.id;
    }
    Events.record(currentUser, 'view', 'user', $scope.userId);
    $scope.canEdit = currentUser.hasPermission('admin') || currentUser.id === parseInt($scope.userId);
    $scope.showSettings = false;
    $scope.showPasswordSettings = false;
    $scope.selectTab = function (tab) {
      _.each($scope.tabs, function (v, k) {
        $scope.tabs[k] = k === tab;
      });
    };
    $scope.setTab = function (tab) {
      $location.hash(tab);
    };
    $scope.tabs = {
      profile: false,
      apiKey: false,
      settings: false,
      password: false
    };
    $scope.selectTab($location.hash() || 'profile');
    $scope.user = User.get({ id: $scope.userId }, function (user) {
      if (user.auth_type == 'password') {
        $scope.showSettings = $scope.canEdit;
        $scope.showPasswordSettings = $scope.canEdit;
      }
    });
    $scope.password = {
      current: '',
      new: '',
      newRepeat: ''
    };
    $scope.savePassword = function (form) {
      $scope.$broadcast('show-errors-check-validity');
      if (!form.$valid) {
        return;
      }
      var data = {
          id: $scope.user.id,
          password: $scope.password.new,
          old_password: $scope.password.current
        };
      User.save(data, function () {
        growl.addSuccessMessage('Password Saved.');
        $scope.password = {
          current: '',
          new: '',
          newRepeat: ''
        };
      }, function (error) {
        var message = error.data.message || 'Failed saving password.';
        growl.addErrorMessage(message);
      });
    };
    $scope.updateUser = function (form) {
      $scope.$broadcast('show-errors-check-validity');
      if (!form.$valid) {
        return;
      }
      var data = {
          id: $scope.user.id,
          name: $scope.user.name,
          email: $scope.user.email
        };
      if ($scope.user.admin === true && $scope.user.groups.indexOf('admin') === -1) {
        data.groups = $scope.user.groups.concat('admin');
      } else if ($scope.user.admin === false && $scope.user.groups.indexOf('admin') !== -1) {
        data.groups = _.without($scope.user.groups, 'admin');
      }
      User.save(data, function (user) {
        growl.addSuccessMessage('Saved.');
        $scope.user = user;
      }, function (error) {
        var message = error.data.message || 'Failed saving.';
        growl.addErrorMessage(message);
      });
    };
  };
  var NewUserCtrl = function ($scope, $location, growl, Events, User) {
    Events.record(currentUser, 'view', 'page', 'users/new');
    $scope.user = new User({});
    $scope.saveUser = function () {
      $scope.$broadcast('show-errors-check-validity');
      if (!$scope.userForm.$valid) {
        return;
      }
      $scope.user.$save(function (user) {
        growl.addSuccessMessage('Saved.');
        $location.path('/users/' + user.id).replace();
      }, function (error) {
        var message = error.data.message || 'Failed saving.';
        growl.addErrorMessage(message);
      });
    };
  };
  angular.module('redash.controllers').controller('UsersCtrl', [
    '$scope',
    '$location',
    'growl',
    'Events',
    'User',
    UsersCtrl
  ]).controller('UserCtrl', [
    '$scope',
    '$routeParams',
    '$http',
    '$location',
    'growl',
    'Events',
    'User',
    UserCtrl
  ]).controller('NewUserCtrl', [
    '$scope',
    '$location',
    'growl',
    'Events',
    'User',
    NewUserCtrl
  ]);
}());
(function () {
  var VisualizationProvider = function () {
    this.visualizations = {};
    this.visualizationTypes = {};
    var defaultConfig = {
        defaultOptions: {},
        skipTypes: false,
        editorTemplate: null
      };
    this.registerVisualization = function (config) {
      var visualization = _.extend({}, defaultConfig, config);
      // TODO: this is prone to errors; better refactor.
      if (_.isEmpty(this.visualizations)) {
        this.defaultVisualization = visualization;
      }
      this.visualizations[config.type] = visualization;
      if (!config.skipTypes) {
        this.visualizationTypes[config.name] = config.type;
      }
      ;
    };
    this.getSwitchTemplate = function (property) {
      var pattern = /(<[a-zA-Z0-9-]*?)( |>)/;
      var mergedTemplates = _.reduce(this.visualizations, function (templates, visualization) {
          if (visualization[property]) {
            var ngSwitch = '$1 ng-switch-when="' + visualization.type + '" $2';
            var template = visualization[property].replace(pattern, ngSwitch);
            return templates + '\n' + template;
          }
          return templates;
        }, '');
      mergedTemplates = '<div ng-switch on="visualization.type">' + mergedTemplates + '</div>';
      return mergedTemplates;
    };
    this.$get = [
      '$resource',
      function ($resource) {
        var Visualization = $resource('/api/visualizations/:id', { id: '@id' });
        Visualization.visualizations = this.visualizations;
        Visualization.visualizationTypes = this.visualizationTypes;
        Visualization.renderVisualizationsTemplate = this.getSwitchTemplate('renderTemplate');
        Visualization.editorTemplate = this.getSwitchTemplate('editorTemplate');
        Visualization.defaultVisualization = this.defaultVisualization;
        return Visualization;
      }
    ];
  };
  var VisualizationName = function (Visualization) {
    return {
      restrict: 'E',
      scope: { visualization: '=' },
      template: '<small>{{name}}</small>',
      replace: false,
      link: function (scope) {
        if (Visualization.visualizations[scope.visualization.type].name != scope.visualization.name) {
          scope.name = scope.visualization.name;
        }
      }
    };
  };
  var VisualizationRenderer = function ($location, Visualization) {
    return {
      restrict: 'E',
      scope: {
        visualization: '=',
        queryResult: '='
      },
      template: '<filters></filters>\n' + Visualization.renderVisualizationsTemplate,
      replace: false,
      link: function (scope) {
        scope.$watch('queryResult && queryResult.getFilters()', function (filters) {
          if (filters) {
            scope.filters = filters;
          }
        });
      }
    };
  };
  var VisualizationOptionsEditor = function (Visualization) {
    return {
      restrict: 'E',
      template: Visualization.editorTemplate,
      replace: false
    };
  };
  var Filters = function () {
    return {
      restrict: 'E',
      templateUrl: '/views/visualizations/filters.html'
    };
  };
  var EditVisualizationForm = function (Events, Visualization, growl) {
    return {
      restrict: 'E',
      templateUrl: '/views/visualizations/edit_visualization.html',
      replace: true,
      scope: {
        query: '=',
        queryResult: '=',
        visualization: '=?',
        openEditor: '@',
        onNewSuccess: '=?'
      },
      link: function (scope, element, attrs) {
        scope.editRawOptions = currentUser.hasPermission('edit_raw_chart');
        scope.visTypes = Visualization.visualizationTypes;
        scope.newVisualization = function () {
          return {
            'type': Visualization.defaultVisualization.type,
            'name': Visualization.defaultVisualization.name,
            'description': '',
            'options': Visualization.defaultVisualization.defaultOptions
          };
        };
        if (!scope.visualization) {
          var unwatch = scope.$watch('query.id', function (queryId) {
              if (queryId) {
                unwatch();
                scope.visualization = scope.newVisualization();
              }
            });
        }
        scope.$watch('visualization.type', function (type, oldType) {
          // if not edited by user, set name to match type
          if (type && oldType != type && scope.visualization && !scope.visForm.name.$dirty) {
            scope.visualization.name = _.string.titleize(scope.visualization.type);
          }
          if (type && oldType != type && scope.visualization) {
            scope.visualization.options = Visualization.visualizations[scope.visualization.type].defaultOptions;
          }
        });
        scope.submit = function () {
          if (scope.visualization.id) {
            Events.record(currentUser, 'update', 'visualization', scope.visualization.id, { 'type': scope.visualization.type });
          } else {
            Events.record(currentUser, 'create', 'visualization', null, { 'type': scope.visualization.type });
          }
          scope.visualization.query_id = scope.query.id;
          Visualization.save(scope.visualization, function success(result) {
            growl.addSuccessMessage('Visualization saved');
            scope.visualization = scope.newVisualization(scope.query);
            var visIds = _.pluck(scope.query.visualizations, 'id');
            var index = visIds.indexOf(result.id);
            if (index > -1) {
              scope.query.visualizations[index] = result;
            } else {
              // new visualization
              scope.query.visualizations.push(result);
              scope.onNewSuccess && scope.onNewSuccess(result);
            }
          }, function error() {
            growl.addErrorMessage('Visualization could not be saved');
          });
        };
      }
    };
  };
  angular.module('redash.visualization', []).provider('Visualization', VisualizationProvider).directive('visualizationRenderer', [
    '$location',
    'Visualization',
    VisualizationRenderer
  ]).directive('visualizationOptionsEditor', [
    'Visualization',
    VisualizationOptionsEditor
  ]).directive('visualizationName', [
    'Visualization',
    VisualizationName
  ]).directive('filters', Filters).directive('editVisulatizationForm', [
    'Events',
    'Visualization',
    'growl',
    EditVisualizationForm
  ]);
}());
(function () {
  var chartVisualization = angular.module('redash.visualization');
  chartVisualization.config([
    'VisualizationProvider',
    function (VisualizationProvider) {
      var renderTemplate = '<chart-renderer options="visualization.options" query-result="queryResult"></chart-renderer>';
      var editTemplate = '<chart-editor></chart-editor>';
      var defaultOptions = { 'series': { 'stacking': null } };
      VisualizationProvider.registerVisualization({
        type: 'CHART',
        name: 'Chart',
        renderTemplate: renderTemplate,
        editorTemplate: editTemplate,
        defaultOptions: defaultOptions
      });
    }
  ]);
  chartVisualization.directive('chartRenderer', function () {
    return {
      restrict: 'E',
      scope: {
        queryResult: '=',
        options: '=?'
      },
      template: '<chart options=\'chartOptions\' series=\'chartSeries\' class=\'graph\'></chart>',
      replace: false,
      controller: [
        '$scope',
        function ($scope) {
          $scope.chartSeries = [];
          $scope.chartOptions = {};
          var reloadData = function (data) {
            if (!data || ($scope.queryResult && $scope.queryResult.getData()) == null) {
              $scope.chartSeries.splice(0, $scope.chartSeries.length);
            } else {
              $scope.chartSeries.splice(0, $scope.chartSeries.length);
              _.each($scope.queryResult.getChartData($scope.options.columnMapping), function (s) {
                var additional = { 'stacking': 'normal' };
                if ('globalSeriesType' in $scope.options) {
                  additional['type'] = $scope.options.globalSeriesType;
                }
                if ($scope.options.seriesOptions && $scope.options.seriesOptions[s.name]) {
                  additional = $scope.options.seriesOptions[s.name];
                  if (!additional.name || additional.name == '') {
                    additional.name = s.name;
                  }
                }
                $scope.chartSeries.push(_.extend(s, additional));
              });
            }
            ;
          };
          $scope.$watch('options', function (chartOptions) {
            if (chartOptions) {
              $scope.chartOptions = chartOptions;
            }
          });
          $scope.$watch('options.seriesOptions', function () {
            reloadData(true);
          }, true);
          $scope.$watchCollection('options.columnMapping', function (chartOptions) {
            reloadData(true);
          });
          $scope.$watch('queryResult && queryResult.getData()', function (data) {
            reloadData(data);
          });
        }
      ]
    };
  });
  chartVisualization.directive('chartEditor', [
    'ColorPalette',
    function (ColorPalette) {
      return {
        restrict: 'E',
        templateUrl: '/views/visualizations/chart_editor.html',
        link: function (scope, element, attrs) {
          scope.palette = ColorPalette;
          scope.seriesTypes = {
            'Line': 'line',
            'Column': 'column',
            'Area': 'area',
            'Scatter': 'scatter',
            'Pie': 'pie'
          };
          scope.globalSeriesType = scope.visualization.options.globalSeriesType || 'column';
          scope.stackingOptions = {
            'None': 'none',
            'Normal': 'normal',
            'Percent': 'percent'
          };
          scope.xAxisOptions = {
            'Date/Time': 'datetime',
            'Linear': 'linear',
            'Category': 'category'
          };
          scope.xAxisType = 'datetime';
          scope.stacking = 'none';
          scope.columnTypes = {
            'X': 'x',
            'Y': 'y',
            'Series': 'series',
            'Unused': 'unused'
          };
          scope.series = [];
          scope.columnTypeSelection = {};
          var chartOptionsUnwatch = null, columnsWatch = null;
          scope.$watch('globalSeriesType', function (type, old) {
            scope.visualization.options.globalSeriesType = type;
            if (type && old && type !== old && scope.visualization.options.seriesOptions) {
              _.each(scope.visualization.options.seriesOptions, function (sOptions) {
                sOptions.type = type;
              });
            }
          });
          scope.$watch('visualization.type', function (visualizationType) {
            if (visualizationType == 'CHART') {
              if (scope.visualization.options.series.stacking === null) {
                scope.stacking = 'none';
              } else if (scope.visualization.options.series.stacking === undefined) {
                scope.stacking = 'normal';
              } else {
                scope.stacking = scope.visualization.options.series.stacking;
              }
              if (scope.visualization.options.sortX === undefined) {
                scope.visualization.options.sortX = true;
              }
              var refreshSeries = function () {
                scope.series = _.map(scope.queryResult.getChartData(scope.visualization.options.columnMapping), function (s) {
                  return s.name;
                });
                // TODO: remove uneeded ones?
                if (scope.visualization.options.seriesOptions == undefined) {
                  scope.visualization.options.seriesOptions = { type: scope.globalSeriesType };
                }
                ;
                _.each(scope.series, function (s, i) {
                  if (scope.visualization.options.seriesOptions[s] == undefined) {
                    scope.visualization.options.seriesOptions[s] = {
                      'type': scope.visualization.options.globalSeriesType,
                      'yAxis': 0
                    };
                  }
                  scope.visualization.options.seriesOptions[s].zIndex = scope.visualization.options.seriesOptions[s].zIndex === undefined ? i : scope.visualization.options.seriesOptions[s].zIndex;
                  scope.visualization.options.seriesOptions[s].index = scope.visualization.options.seriesOptions[s].index === undefined ? i : scope.visualization.options.seriesOptions[s].index;
                });
                scope.zIndexes = _.range(scope.series.length);
                scope.yAxes = [
                  [
                    0,
                    'left'
                  ],
                  [
                    1,
                    'right'
                  ]
                ];
              };
              var initColumnMapping = function () {
                scope.columns = scope.queryResult.getColumns();
                if (scope.visualization.options.columnMapping == undefined) {
                  scope.visualization.options.columnMapping = {};
                }
                scope.columnTypeSelection = scope.visualization.options.columnMapping;
                _.each(scope.columns, function (column) {
                  var definition = column.name.split('::'), definedColumns = _.keys(scope.visualization.options.columnMapping);
                  if (_.indexOf(definedColumns, column.name) != -1) {
                    // Skip already defined columns.
                    return;
                  }
                  ;
                  if (definition.length == 1) {
                    scope.columnTypeSelection[column.name] = scope.visualization.options.columnMapping[column.name] = 'unused';
                  } else if (definition == 'multi-filter') {
                    scope.columnTypeSelection[column.name] = scope.visualization.options.columnMapping[column.name] = 'series';
                  } else if (_.indexOf(_.values(scope.columnTypes), definition[1]) != -1) {
                    scope.columnTypeSelection[column.name] = scope.visualization.options.columnMapping[column.name] = definition[1];
                  } else {
                    scope.columnTypeSelection[column.name] = scope.visualization.options.columnMapping[column.name] = 'unused';
                  }
                });
              };
              columnsWatch = scope.$watch('queryResult.getId()', function (id) {
                if (!id) {
                  return;
                }
                initColumnMapping();
                refreshSeries();
              });
              scope.$watchCollection('columnTypeSelection', function (selections) {
                _.each(scope.columnTypeSelection, function (type, name) {
                  scope.visualization.options.columnMapping[name] = type;
                });
                refreshSeries();
              });
              chartOptionsUnwatch = scope.$watch('stacking', function (stacking) {
                if (stacking == 'none') {
                  scope.visualization.options.series.stacking = null;
                } else {
                  scope.visualization.options.series.stacking = stacking;
                }
              });
              scope.visualization.options.xAxis = scope.visualization.options.xAxis || {};
              scope.visualization.options.xAxis.labels = scope.visualization.options.xAxis.labels || {};
              if (scope.visualization.options.xAxis.labels.enabled === undefined) {
                scope.visualization.options.xAxis.labels.enabled = true;
              }
              scope.xAxisType = scope.visualization.options.xAxis && scope.visualization.options.xAxis.type || scope.xAxisType;
              xAxisUnwatch = scope.$watch('xAxisType', function (xAxisType) {
                scope.visualization.options.xAxis = scope.visualization.options.xAxis || {};
                scope.visualization.options.xAxis.type = xAxisType;
              });
            } else {
              if (chartOptionsUnwatch) {
                chartOptionsUnwatch();
                chartOptionsUnwatch = null;
              }
              if (columnsWatch) {
                columnWatch();
                columnWatch = null;
              }
              if (xAxisUnwatch) {
                xAxisUnwatch();
                xAxisUnwatch = null;
              }
            }
          });
        }
      };
    }
  ]);
}());
(function () {
  var cohortVisualization = angular.module('redash.visualization');
  cohortVisualization.config([
    'VisualizationProvider',
    function (VisualizationProvider) {
      VisualizationProvider.registerVisualization({
        type: 'COHORT',
        name: 'Cohort',
        renderTemplate: '<cohort-renderer options="visualization.options" query-result="queryResult"></cohort-renderer>'
      });
    }
  ]);
  cohortVisualization.directive('cohortRenderer', function () {
    return {
      restrict: 'E',
      scope: { queryResult: '=' },
      template: '',
      replace: false,
      link: function ($scope, element, attrs) {
        $scope.$watch('queryResult && queryResult.getData()', function (data) {
          if (!data) {
            return;
          }
          if ($scope.queryResult.getData() == null) {
          } else {
            var sortedData = _.sortBy($scope.queryResult.getData(), function (r) {
                return r['date'] + r['day_number'];
              });
            var grouped = _.groupBy(sortedData, 'date');
            var maxColumns = _.reduce(grouped, function (memo, data) {
                return data.length > memo ? data.length : memo;
              }, 0);
            var data = _.map(grouped, function (values, date) {
                var row = [values[0].total];
                _.each(values, function (value) {
                  row.push(value.value);
                });
                _.each(_.range(values.length, maxColumns), function () {
                  row.push(null);
                });
                return row;
              });
            var initialDate = moment(sortedData[0].date).toDate(), container = angular.element(element)[0];
            Cornelius.draw({
              initialDate: initialDate,
              container: container,
              cohort: data,
              title: null,
              timeInterval: 'daily',
              labels: {
                time: 'Activation Day',
                people: 'Users'
              },
              formatHeaderLabel: function (i) {
                return 'Day ' + (i - 1);
              }
            });
          }
        });
      }
    };
  });
}());
'use strict';
(function () {
  var module = angular.module('redash.visualization');
  module.config([
    'VisualizationProvider',
    function (VisualizationProvider) {
      var renderTemplate = '<map-renderer ' + 'options="visualization.options" query-result="queryResult">' + '</map-renderer>';
      var editTemplate = '<map-editor></map-editor>';
      var defaultOptions = {
          'height': 500,
          'draw': 'Marker',
          'classify': 'none'
        };
      VisualizationProvider.registerVisualization({
        type: 'MAP',
        name: 'Map',
        renderTemplate: renderTemplate,
        editorTemplate: editTemplate,
        defaultOptions: defaultOptions
      });
    }
  ]);
  module.directive('mapRenderer', function () {
    return {
      restrict: 'E',
      templateUrl: '/views/visualizations/map.html',
      link: function ($scope, elm, attrs) {
        var setBounds = function () {
          var b = $scope.visualization.options.bounds;
          if (b) {
            $scope.map.fitBounds([
              [
                b._southWest.lat,
                b._southWest.lng
              ],
              [
                b._northEast.lat,
                b._northEast.lng
              ]
            ]);
          } else if ($scope.features.length > 0) {
            var group = new L.featureGroup($scope.features);
            $scope.map.fitBounds(group.getBounds());
          }
        };
        $scope.$watch('[queryResult && queryResult.getData(), visualization.options.draw,visualization.options.latColName,' + 'visualization.options.lonColName,visualization.options.classify,visualization.options.classify]', function () {
          var marker = function (lat, lon) {
            if (lat == null || lon == null)
              return;
            return L.marker([
              lat,
              lon
            ]);
          };
          var heatpoint = function (lat, lon, obj) {
            if (lat == null || lon == null)
              return;
            var color = 'red';
            if (obj && obj[$scope.visualization.options.classify] && $scope.visualization.options.classification) {
              var v = $.grep($scope.visualization.options.classification, function (e) {
                  return e.value == obj[$scope.visualization.options.classify];
                });
              if (v.length > 0)
                color = v[0].color;
            }
            var style = {
                fillColor: color,
                fillOpacity: 0.5,
                stroke: false
              };
            return L.circleMarker([
              lat,
              lon
            ], style);
          };
          var color = function (val) {
            // taken from http://jsfiddle.net/xgJ2e/2/
            var h = Math.floor((100 - val) * 120 / 100);
            var s = Math.abs(val - 50) / 50;
            var v = 1;
            var rgb, i, data = [];
            if (s === 0) {
              rgb = [
                v,
                v,
                v
              ];
            } else {
              h = h / 60;
              i = Math.floor(h);
              data = [
                v * (1 - s),
                v * (1 - s * (h - i)),
                v * (1 - s * (1 - (h - i)))
              ];
              switch (i) {
              case 0:
                rgb = [
                  v,
                  data[2],
                  data[0]
                ];
                break;
              case 1:
                rgb = [
                  data[1],
                  v,
                  data[0]
                ];
                break;
              case 2:
                rgb = [
                  data[0],
                  v,
                  data[2]
                ];
                break;
              case 3:
                rgb = [
                  data[0],
                  data[1],
                  v
                ];
                break;
              case 4:
                rgb = [
                  data[2],
                  data[0],
                  v
                ];
                break;
              default:
                rgb = [
                  v,
                  data[0],
                  data[1]
                ];
                break;
              }
            }
            return '#' + rgb.map(function (x) {
              return ('0' + Math.round(x * 255).toString(16)).slice(-2);
            }).join('');
          };
          // Following line is used to avoid "Couldn't autodetect L.Icon.Default.imagePath" error
          // https://github.com/Leaflet/Leaflet/issues/766#issuecomment-7741039
          L.Icon.Default.imagePath = L.Icon.Default.imagePath || '//api.tiles.mapbox.com/mapbox.js/v2.2.1/images';
          function getBounds(e) {
            $scope.visualization.options.bounds = $scope.map.getBounds();
          }
          var queryData = $scope.queryResult.getData();
          var classify = $scope.visualization.options.classify;
          if (queryData) {
            $scope.visualization.options.classification = [];
            for (var row in queryData) {
              if (queryData[row][classify] && $.grep($scope.visualization.options.classification, function (e) {
                  return e.value == queryData[row][classify];
                }).length == 0) {
                $scope.visualization.options.classification.push({
                  value: queryData[row][classify],
                  color: null
                });
              }
            }
            $.each($scope.visualization.options.classification, function (i, c) {
              c.color = color(parseInt(i / $scope.visualization.options.classification.length * 100));
            });
            if (!$scope.map) {
              $scope.map = L.map(elm[0].children[0].children[0]);
            }
            L.tileLayer('//{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors' }).addTo($scope.map);
            $scope.features = $scope.features || [];
            var tmp_features = [];
            var lat_col = $scope.visualization.options.latColName || 'lat';
            var lon_col = $scope.visualization.options.lonColName || 'lon';
            for (var row in queryData) {
              var feature;
              if ($scope.visualization.options.draw == 'Marker') {
                feature = marker(queryData[row][lat_col], queryData[row][lon_col]);
              } else if ($scope.visualization.options.draw == 'Color') {
                feature = heatpoint(queryData[row][lat_col], queryData[row][lon_col], queryData[row]);
              }
              if (!feature)
                continue;
              var obj_description = '<ul style="list-style-type: none;padding-left: 0">';
              for (var k in queryData[row]) {
                obj_description += '<li>' + k + ': ' + queryData[row][k] + '</li>';
              }
              obj_description += '</ul>';
              feature.bindPopup(obj_description);
              tmp_features.push(feature);
            }
            $.each($scope.features, function (i, f) {
              $scope.map.removeLayer(f);
            });
            $scope.features = tmp_features;
            $.each($scope.features, function (i, f) {
              f.addTo($scope.map);
            });
            setBounds();
            $scope.map.on('focus', function () {
              $scope.map.on('moveend', getBounds);
            });
            $scope.map.on('blur', function () {
              $scope.map.off('moveend', getBounds);
            });
            // We redraw the map if it was loaded in a hidden tab
            if ($('a[href="#' + $scope.visualization.id + '"]').length > 0) {
              $('a[href="#' + $scope.visualization.id + '"]').on('click', function () {
                setTimeout(function () {
                  $scope.map.invalidateSize(false);
                  setBounds();
                }, 500);
              });
            }
          }
        }, true);
        $scope.$watch('visualization.options.height', function () {
          if (!$scope.map)
            return;
          $scope.map.invalidateSize(false);
          setBounds();
        });
      }
    };
  });
  module.directive('mapEditor', function () {
    return {
      restrict: 'E',
      templateUrl: '/views/visualizations/map_editor.html',
      link: function ($scope, elm, attrs) {
        $scope.draw_options = [
          'Marker',
          'Color'
        ];
        $scope.classify_columns = $scope.queryResult.columnNames.concat('none');
      }
    };
  });
}());
'use strict';
(function () {
  var module = angular.module('redash.visualization');
  module.config([
    'VisualizationProvider',
    function (VisualizationProvider) {
      var renderTemplate = '<counter-renderer ' + 'options="visualization.options" query-result="queryResult">' + '</counter-renderer>';
      var editTemplate = '<counter-editor></counter-editor>';
      var defaultOptions = {
          counterColName: 'counter',
          rowNumber: 1,
          targetRowNumber: 1
        };
      VisualizationProvider.registerVisualization({
        type: 'COUNTER',
        name: 'Counter',
        renderTemplate: renderTemplate,
        editorTemplate: editTemplate,
        defaultOptions: defaultOptions
      });
    }
  ]);
  module.directive('counterRenderer', function () {
    return {
      restrict: 'E',
      templateUrl: '/views/visualizations/counter.html',
      link: function ($scope, elm, attrs) {
        $scope.$watch('[queryResult && queryResult.getData(), visualization.options]', function () {
          var queryData = $scope.queryResult.getData();
          if (queryData) {
            var rowNumber = $scope.visualization.options.rowNumber - 1;
            var targetRowNumber = $scope.visualization.options.targetRowNumber - 1;
            var counterColName = $scope.visualization.options.counterColName;
            var targetColName = $scope.visualization.options.targetColName;
            if (counterColName) {
              $scope.counterValue = queryData[rowNumber][counterColName];
            }
            if (targetColName) {
              $scope.targetValue = queryData[targetRowNumber][targetColName];
              if ($scope.targetValue) {
                $scope.delta = $scope.counterValue - $scope.targetValue;
                $scope.trendPositive = $scope.delta >= 0;
              }
            } else {
              $scope.targetValue = null;
            }
          }
        }, true);
      }
    };
  });
  module.directive('counterEditor', function () {
    return {
      restrict: 'E',
      templateUrl: '/views/visualizations/counter_editor.html'
    };
  });
}());
(function () {
  var tableVisualization = angular.module('redash.visualization');
  tableVisualization.config([
    'VisualizationProvider',
    function (VisualizationProvider) {
      VisualizationProvider.registerVisualization({
        type: 'TABLE',
        name: 'Table',
        renderTemplate: '<grid-renderer options="visualization.options" query-result="queryResult"></grid-renderer>',
        skipTypes: true
      });
    }
  ]);
  tableVisualization.directive('gridRenderer', function () {
    return {
      restrict: 'E',
      scope: {
        queryResult: '=',
        itemsPerPage: '='
      },
      templateUrl: '/views/grid_renderer.html',
      replace: false,
      controller: [
        '$scope',
        '$filter',
        function ($scope, $filter) {
          $scope.gridColumns = [];
          $scope.gridData = [];
          $scope.gridConfig = {
            isPaginationEnabled: true,
            itemsByPage: $scope.itemsPerPage || 15,
            maxSize: 8
          };
          $scope.$watch('queryResult && queryResult.getData()', function (data) {
            if (!data) {
              return;
            }
            if ($scope.queryResult.getData() == null) {
              $scope.gridColumns = [];
              $scope.gridData = [];
              $scope.filters = [];
            } else {
              $scope.filters = $scope.queryResult.getFilters();
              var prepareGridData = function (data) {
                var gridData = _.map(data, function (row) {
                    var newRow = {};
                    _.each(row, function (val, key) {
                      newRow[$scope.queryResult.getColumnCleanName(key)] = val;
                    });
                    return newRow;
                  });
                return gridData;
              };
              $scope.gridData = prepareGridData($scope.queryResult.getData());
              var columns = $scope.queryResult.getColumns();
              $scope.gridColumns = _.map($scope.queryResult.getColumnCleanNames(), function (col, i) {
                var columnDefinition = {
                    'label': $scope.queryResult.getColumnFriendlyNames()[i],
                    'map': col
                  };
                var columnType = columns[i].type;
                if (columnType === 'integer') {
                  columnDefinition.formatFunction = 'number';
                  columnDefinition.formatParameter = 0;
                } else if (columnType === 'float') {
                  columnDefinition.formatFunction = 'number';
                  columnDefinition.formatParameter = 2;
                } else if (columnType === 'boolean') {
                  columnDefinition.formatFunction = function (value) {
                    if (value !== undefined) {
                      return '' + value;
                    }
                    return value;
                  };
                } else if (columnType === 'date') {
                  columnDefinition.formatFunction = function (value) {
                    if (value && moment.isMoment(value)) {
                      return value.toDate().toLocaleDateString();
                    }
                    return value;
                  };
                } else if (columnType === 'datetime') {
                  columnDefinition.formatFunction = function (value) {
                    if (value && moment.isMoment(value)) {
                      return value.toDate().toLocaleString();
                    }
                    return value;
                  };
                } else {
                  columnDefinition.formatFunction = function (value) {
                    if (angular.isString(value)) {
                      value = $filter('linkify')(value);
                    }
                    return value;
                  };
                }
                return columnDefinition;
              });
            }
          });
        }
      ]
    };
  });
}());
var renderers = angular.module('redash.renderers', []);
renderers.directive('pivotTableRenderer', function () {
  return {
    restrict: 'E',
    scope: { queryResult: '=' },
    template: '',
    replace: false,
    link: function ($scope, element, attrs) {
      $scope.$watch('queryResult && queryResult.getData()', function (data) {
        if (!data) {
          return;
        }
        if ($scope.queryResult.getData() == null) {
        } else {
          // We need to give the pivot table its own copy of the data, because its change
          // it which interferes with other visualizations.
          var data = $.extend(true, [], $scope.queryResult.getData());
          $(element).pivotUI(data, { renderers: $.pivotUtilities.renderers }, true);
        }
      });
    }
  };
});
(function () {
  'use strict';
  var directives = angular.module('redash.directives', []);
  directives.directive('alertUnsavedChanges', [
    '$window',
    function ($window) {
      return {
        restrict: 'E',
        replace: true,
        scope: { 'isDirty': '=' },
        link: function ($scope) {
          var unloadMessage = 'You will lose your changes if you leave', confirmMessage = unloadMessage + '\n\nAre you sure you want to leave this page?',
            // store original handler (if any)
            _onbeforeunload = $window.onbeforeunload;
          $window.onbeforeunload = function () {
            return $scope.isDirty ? unloadMessage : null;
          };
          $scope.$on('$locationChangeStart', function (event, next, current) {
            if (next.split('#')[0] == current.split('#')[0]) {
              return;
            }
            if ($scope.isDirty && !confirm(confirmMessage)) {
              event.preventDefault();
            }
          });
          $scope.$on('$destroy', function () {
            $window.onbeforeunload = _onbeforeunload;
          });
        }
      };
    }
  ]);
  directives.directive('rdTab', function () {
    return {
      restrict: 'E',
      scope: {
        'tabId': '@',
        'name': '@'
      },
      transclude: true,
      template: '<li class="rd-tab" ng-class="{active: tabId==selectedTab}"><a href="#{{tabId}}">{{name}}<span ng-transclude></span></a></li>',
      replace: true,
      link: function (scope) {
        scope.$watch(function () {
          return scope.$parent.selectedTab;
        }, function (tab) {
          scope.selectedTab = tab;
        });
      }
    };
  });
  directives.directive('rdTabs', [
    '$location',
    function ($location) {
      return {
        restrict: 'E',
        scope: {
          tabsCollection: '=',
          selectedTab: '='
        },
        template: '<ul class="nav nav-tabs"><li ng-class="{active: tab==selectedTab}" ng-repeat="tab in tabsCollection"><a href="#{{tab.key}}">{{tab.name}}</a></li></ul>',
        replace: true,
        link: function ($scope, element, attrs) {
          $scope.selectTab = function (tabKey) {
            $scope.selectedTab = _.find($scope.tabsCollection, function (tab) {
              return tab.key == tabKey;
            });
          };
          $scope.$watch(function () {
            return $location.hash();
          }, function (hash) {
            if (hash) {
              $scope.selectTab($location.hash());
            } else {
              $scope.selectTab($scope.tabsCollection[0].key);
            }
          });
        }
      };
    }
  ]);
  // From: http://jsfiddle.net/joshdmiller/NDFHg/
  directives.directive('editInPlace', function () {
    return {
      restrict: 'E',
      scope: {
        value: '=',
        ignoreBlanks: '=',
        editable: '=',
        done: '='
      },
      template: function (tElement, tAttrs) {
        var elType = tAttrs.editor || 'input';
        var placeholder = tAttrs.placeholder || 'Click to edit';
        var viewMode = '';
        if (tAttrs.markdown == 'true') {
          viewMode = '<span ng-click="editable && edit()" ng-bind-html="value|markdown" ng-class="{editable: editable}"></span>';
        } else {
          viewMode = '<span ng-click="editable && edit()" ng-bind="value" ng-class="{editable: editable}"></span>';
        }
        var placeholderSpan = '<span ng-click="editable && edit()" ng-show="editable && !value" ng-class="{editable: editable}">' + placeholder + '</span>';
        var editor = '<{elType} ng-model="value" class="rd-form-control"></{elType}>'.replace('{elType}', elType);
        return viewMode + placeholderSpan + editor;
      },
      link: function ($scope, element, attrs) {
        // Let's get a reference to the input element, as we'll want to reference it.
        var inputElement = angular.element(element.children()[2]);
        // This directive should have a set class so we can style it.
        element.addClass('edit-in-place');
        // Initially, we're not editing.
        $scope.editing = false;
        // ng-click handler to activate edit-in-place
        $scope.edit = function () {
          $scope.oldValue = $scope.value;
          $scope.editing = true;
          // We control display through a class on the directive itself. See the CSS.
          element.addClass('active');
          // And we must focus the element.
          // `angular.element()` provides a chainable array, like jQuery so to access a native DOM function,
          // we have to reference the first element in the array.
          inputElement[0].focus();
        };
        function save() {
          if ($scope.editing) {
            if ($scope.ignoreBlanks && _.isEmpty($scope.value)) {
              $scope.value = $scope.oldValue;
            }
            $scope.editing = false;
            element.removeClass('active');
            if ($scope.value !== $scope.oldValue) {
              $scope.done && $scope.done();
            }
          }
        }
        $(inputElement).keydown(function (e) {
          // 'return' or 'enter' key pressed
          // allow 'shift' to break lines
          if (e.which === 13 && !e.shiftKey) {
            save();
          } else if (e.which === 27) {
            $scope.value = $scope.oldValue;
            $scope.$apply(function () {
              $(inputElement[0]).blur();
            });
          }
        }).blur(function () {
          save();
        });
      }
    };
  });
  // http://stackoverflow.com/a/17904092/1559840
  directives.directive('jsonText', function () {
    return {
      restrict: 'A',
      require: 'ngModel',
      link: function (scope, element, attr, ngModel) {
        function into(input) {
          return JSON.parse(input);
        }
        function out(data) {
          return JSON.stringify(data, undefined, 2);
        }
        ngModel.$parsers.push(into);
        ngModel.$formatters.push(out);
        scope.$watch(attr.ngModel, function (newValue) {
          element[0].value = out(newValue);
        }, true);
      }
    };
  });
  directives.directive('rdTimer', [function () {
      return {
        restrict: 'E',
        scope: { timestamp: '=' },
        template: '{{currentTime}}',
        controller: [
          '$scope',
          function ($scope) {
            $scope.currentTime = '00:00:00';
            // We're using setInterval directly instead of $timeout, to avoid using $apply, to
            // prevent the digest loop being run every second.
            var currentTimer = setInterval(function () {
                $scope.currentTime = moment(moment() - moment($scope.timestamp)).utc().format('HH:mm:ss');
                $scope.$digest();
              }, 1000);
            $scope.$on('$destroy', function () {
              if (currentTimer) {
                clearInterval(currentTimer);
                currentTimer = null;
              }
            });
          }
        ]
      };
    }]);
  directives.directive('rdTimeAgo', function () {
    return {
      restrict: 'E',
      scope: { value: '=' },
      template: '<span>' + '<span ng-show="value" am-time-ago="value"></span>' + '<span ng-hide="value">-</span>' + '</span>'
    };
  });
  // Used instead of autofocus attribute, which doesn't work in Angular as there is no real page load.
  directives.directive('autofocus', [
    '$timeout',
    function ($timeout) {
      return {
        link: function (scope, element) {
          $timeout(function () {
            element[0].focus();
          });
        }
      };
    }
  ]);
  directives.directive('compareTo', function () {
    return {
      require: 'ngModel',
      scope: { otherModelValue: '=compareTo' },
      link: function (scope, element, attributes, ngModel) {
        var validate = function (value) {
          ngModel.$setValidity('compareTo', value === scope.otherModelValue);
        };
        scope.$watch('otherModelValue', function () {
          validate(ngModel.$modelValue);
        });
        ngModel.$parsers.push(function (value) {
          validate(value);
          return value;
        });
      }
    };
  });
  directives.directive('inputErrors', function () {
    return {
      restrict: 'E',
      templateUrl: '/views/directives/input_errors.html',
      replace: true,
      scope: { errors: '=' }
    };
  });
}());
(function () {
  'use strict';
  function queryLink() {
    return {
      restrict: 'E',
      scope: {
        'query': '=',
        'visualization': '=?'
      },
      template: '<small><span class="glyphicon glyphicon-link"></span></small> <a ng-href="{{link}}" class="query-link">{{query.name}}</a>',
      link: function (scope, element) {
        scope.link = '/queries/' + scope.query.id;
        if (scope.visualization) {
          if (scope.visualization.type === 'TABLE') {
            // link to hard-coded table tab instead of the (hidden) visualization tab
            scope.link += '#table';
          } else {
            scope.link += '#' + scope.visualization.id;
          }
        }  // element.find('a').attr('href', link);
      }
    };
  }
  function querySourceLink() {
    return {
      restrict: 'E',
      template: '<span ng-show="query.id && canViewSource">                    <a ng-show="!sourceMode"                      ng-href="/queries/{{query.id}}/source#{{selectedTab}}">Show Source                    </a>                    <a ng-show="sourceMode"                      ng-href="/queries/{{query.id}}#{{selectedTab}}">Hide Source                    </a>                </span>'
    };
  }
  function queryResultCSVLink() {
    return {
      restrict: 'A',
      link: function (scope, element) {
        scope.$watch('queryResult && queryResult.getData()', function (data) {
          if (!data) {
            return;
          }
          if (scope.queryResult.getId() == null) {
            element.attr('href', '');
          } else {
            element.attr('href', '/api/queries/' + scope.query.id + '/results/' + scope.queryResult.getId() + '.csv');
            element.attr('download', scope.query.name.replace(' ', '_') + moment(scope.queryResult.getUpdatedAt()).format('_YYYY_MM_DD') + '.csv');
          }
        });
      }
    };
  }
  function queryEditor() {
    return {
      restrict: 'E',
      scope: {
        'query': '=',
        'lock': '=',
        'schema': '=',
        'syntax': '='
      },
      template: '<textarea></textarea>',
      link: {
        pre: function ($scope, element) {
          $scope.syntax = $scope.syntax || 'sql';
          var modes = {
              'sql': 'text/x-sql',
              'python': 'text/x-python',
              'json': 'application/json'
            };
          var textarea = element.children()[0];
          var editorOptions = {
              mode: modes[$scope.syntax],
              lineWrapping: true,
              lineNumbers: true,
              readOnly: false,
              matchBrackets: true,
              autoCloseBrackets: true,
              extraKeys: { 'Ctrl-Space': 'autocomplete' }
            };
          var additionalHints = [];
          CodeMirror.commands.autocomplete = function (cm) {
            var hinter = function (editor, options) {
              var hints = CodeMirror.hint.anyword(editor, options);
              var cur = editor.getCursor(), token = editor.getTokenAt(cur).string;
              hints.list = _.union(hints.list, _.filter(additionalHints, function (h) {
                return h.search(token) === 0;
              }));
              return hints;
            };
            //            CodeMirror.showHint(cm, CodeMirror.hint.anyword);
            CodeMirror.showHint(cm, hinter);
          };
          var codemirror = CodeMirror.fromTextArea(textarea, editorOptions);
          codemirror.on('change', function (instance) {
            var newValue = instance.getValue();
            if (newValue !== $scope.query.query) {
              $scope.$evalAsync(function () {
                $scope.query.query = newValue;
              });
            }
            $('.schema-container').css('height', $('.CodeMirror').css('height'));
          });
          $scope.$watch('query.query', function () {
            if ($scope.query.query !== codemirror.getValue()) {
              codemirror.setValue($scope.query.query);
            }
          });
          $scope.$watch('schema', function (schema) {
            if (schema) {
              var keywords = [];
              _.each(schema, function (table) {
                keywords.push(table.name);
                _.each(table.columns, function (c) {
                  keywords.push(c);
                });
              });
              additionalHints = _.unique(keywords);
            }
            codemirror.refresh();
          });
          $scope.$watch('syntax', function (syntax) {
            codemirror.setOption('mode', modes[syntax]);
          });
          $scope.$watch('lock', function (locked) {
            var readOnly = locked ? 'nocursor' : false;
            codemirror.setOption('readOnly', readOnly);
          });
        }
      }
    };
  }
  function queryFormatter($http) {
    return {
      restrict: 'E',
      scope: false,
      template: '<button type="button" class="btn btn-default btn-xs"                   ng-click="formatQuery()">                    <span class="glyphicon glyphicon-indent-left"></span>                     Format SQL                </button>',
      link: function ($scope) {
        $scope.formatQuery = function formatQuery() {
          $scope.queryFormatting = true;
          $http.post('/api/queries/format', { 'query': $scope.query.query }).success(function (response) {
            $scope.query.query = response;
          }).finally(function () {
            $scope.queryFormatting = false;
          });
        };
      }
    };
  }
  function queryTimePicker() {
    return {
      restrict: 'E',
      template: '<select ng-disabled="refreshType != \'daily\'" ng-model="hour" ng-change="updateSchedule()" ng-options="c as c for c in hourOptions"></select> :                 <select ng-disabled="refreshType != \'daily\'" ng-model="minute" ng-change="updateSchedule()" ng-options="c as c for c in minuteOptions"></select>',
      link: function ($scope) {
        var padWithZeros = function (size, v) {
          v = String(v);
          if (v.length < size) {
            v = '0' + v;
          }
          return v;
        };
        $scope.hourOptions = _.map(_.range(0, 24), _.partial(padWithZeros, 2));
        $scope.minuteOptions = _.map(_.range(0, 60, 5), _.partial(padWithZeros, 2));
        if ($scope.query.hasDailySchedule()) {
          var parts = $scope.query.scheduleInLocalTime().split(':');
          $scope.minute = parts[1];
          $scope.hour = parts[0];
        } else {
          $scope.minute = '15';
          $scope.hour = '00';
        }
        $scope.updateSchedule = function () {
          var newSchedule = moment().hour($scope.hour).minute($scope.minute).utc().format('HH:mm');
          if (newSchedule != $scope.query.schedule) {
            $scope.query.schedule = newSchedule;
            $scope.saveQuery();
          }
        };
        $scope.$watch('refreshType', function () {
          if ($scope.refreshType == 'daily') {
            $scope.updateSchedule();
          }
        });
      }
    };
  }
  function queryRefreshSelect() {
    return {
      restrict: 'E',
      template: '<select                  ng-disabled="refreshType != \'periodic\'"                  ng-model="query.schedule"                  ng-change="saveQuery()"                  ng-options="c.value as c.name for c in refreshOptions">                  <option value="">No Refresh</option>                  </select>',
      link: function ($scope) {
        $scope.refreshOptions = [{
            value: '60',
            name: 'Every minute'
          }];
        _.each([
          5,
          10,
          15,
          30
        ], function (i) {
          $scope.refreshOptions.push({
            value: String(i * 60),
            name: 'Every ' + i + ' minutes'
          });
        });
        _.each(_.range(1, 13), function (i) {
          $scope.refreshOptions.push({
            value: String(i * 3600),
            name: 'Every ' + i + 'h'
          });
        });
        $scope.refreshOptions.push({
          value: String(24 * 3600),
          name: 'Every 24h'
        });
        $scope.refreshOptions.push({
          value: String(7 * 24 * 3600),
          name: 'Once a week'
        });
        $scope.$watch('refreshType', function () {
          if ($scope.refreshType == 'periodic') {
            if ($scope.query.hasDailySchedule()) {
              $scope.query.schedule = null;
              $scope.saveQuery();
            }
          }
        });
      }
    };
  }
  angular.module('redash.directives').directive('queryLink', queryLink).directive('querySourceLink', querySourceLink).directive('queryResultLink', queryResultCSVLink).directive('queryEditor', queryEditor).directive('queryRefreshSelect', queryRefreshSelect).directive('queryTimePicker', queryTimePicker).directive('queryFormatter', [
    '$http',
    queryFormatter
  ]);
}());
(function () {
  'use strict';
  var directives = angular.module('redash.directives');
  // Angular strips data- from the directive, so data-source-form becomes sourceForm...
  directives.directive('sourceForm', [
    '$http',
    'growl',
    function ($http, growl) {
      return {
        restrict: 'E',
        replace: true,
        templateUrl: '/views/data_sources/form.html',
        scope: { 'dataSource': '=' },
        link: function ($scope) {
          var setType = function (types) {
            if ($scope.dataSource.type === undefined) {
              $scope.dataSource.type = types[0].type;
              return types[0];
            }
            $scope.type = _.find(types, function (t) {
              return t.type == $scope.dataSource.type;
            });
          };
          $scope.files = {};
          $scope.$watchCollection('files', function () {
            _.each($scope.files, function (v, k) {
              if (v) {
                $scope.dataSource.options[k] = v.base64;
              }
            });
          });
          $http.get('/api/data_sources/types').success(function (types) {
            setType(types);
            $scope.dataSourceTypes = types;
            _.each(types, function (type) {
              _.each(type.configuration_schema.properties, function (prop, name) {
                if (name == 'password' || name == 'passwd') {
                  prop.type = 'password';
                }
                if (_.string.endsWith(name, 'File')) {
                  prop.type = 'file';
                }
                prop.required = _.contains(type.configuration_schema.required, name);
              });
            });
          });
          $scope.$watch('dataSource.type', function (current, prev) {
            if (prev !== current) {
              if (prev !== undefined) {
                $scope.dataSource.options = {};
              }
              setType($scope.dataSourceTypes);
            }
          });
          $scope.saveChanges = function () {
            $scope.dataSource.$save(function () {
              growl.addSuccessMessage('Saved.');
            }, function () {
              growl.addErrorMessage('Failed saving.');
            });
          };
        }
      };
    }
  ]);
}());
(function () {
  'use strict';
  var directives = angular.module('redash.directives');
  directives.directive('editDashboardForm', [
    'Events',
    '$http',
    '$location',
    '$timeout',
    'Dashboard',
    function (Events, $http, $location, $timeout, Dashboard) {
      return {
        restrict: 'E',
        scope: { dashboard: '=' },
        templateUrl: '/views/edit_dashboard.html',
        replace: true,
        link: function ($scope, element, attrs) {
          var gridster = element.find('.gridster ul').gridster({
              widget_margins: [
                5,
                5
              ],
              widget_base_dimensions: [
                260,
                100
              ],
              min_cols: 2,
              max_cols: 2,
              serialize_params: function ($w, wgd) {
                return {
                  col: wgd.col,
                  row: wgd.row,
                  id: $w.data('widget-id')
                };
              }
            }).data('gridster');
          var gsItemTemplate = '<li data-widget-id="{id}" class="widget panel panel-default gs-w">' + '<div class="panel-heading">{name}' + '</div></li>';
          $scope.$watch('dashboard.widgets && dashboard.widgets.length', function (widgets_length) {
            $timeout(function () {
              gridster.remove_all_widgets();
              if ($scope.dashboard.widgets && $scope.dashboard.widgets.length) {
                var layout = [];
                _.each($scope.dashboard.widgets, function (row, rowIndex) {
                  _.each(row, function (widget, colIndex) {
                    layout.push({
                      id: widget.id,
                      col: colIndex + 1,
                      row: rowIndex + 1,
                      ySize: 1,
                      xSize: widget.width,
                      name: widget.getName()
                    });
                  });
                });
                _.each(layout, function (item) {
                  var el = gsItemTemplate.replace('{id}', item.id).replace('{name}', item.name);
                  gridster.add_widget(el, item.xSize, item.ySize, item.col, item.row);
                });
              }
            });
          });
          $scope.saveDashboard = function () {
            $scope.saveInProgress = true;
            // TODO: we should use the dashboard service here.
            if ($scope.dashboard.id) {
              var positions = $(element).find('.gridster ul').data('gridster').serialize();
              var layout = [];
              _.each(_.sortBy(positions, function (pos) {
                return pos.row * 10 + pos.col;
              }), function (pos) {
                var row = pos.row - 1;
                var col = pos.col - 1;
                layout[row] = layout[row] || [];
                if (col > 0 && layout[row][col - 1] == undefined) {
                  layout[row][col - 1] = pos.id;
                } else {
                  layout[row][col] = pos.id;
                }
              });
              $scope.dashboard.layout = layout;
              layout = JSON.stringify(layout);
              $http.post('/api/dashboards/' + $scope.dashboard.id, {
                'name': $scope.dashboard.name,
                'layout': layout
              }).success(function (response) {
                $scope.dashboard = new Dashboard(response);
                $scope.saveInProgress = false;
                $(element).modal('hide');
              });
              Events.record(currentUser, 'edit', 'dashboard', $scope.dashboard.id);
            } else {
              $http.post('/api/dashboards', { 'name': $scope.dashboard.name }).success(function (response) {
                $(element).modal('hide');
                $scope.dashboard = {
                  'name': null,
                  'layout': null
                };
                $scope.saveInProgress = false;
                $location.path('/dashboard/' + response.slug).replace();
              });
              Events.record(currentUser, 'create', 'dashboard');
            }
          };
        }
      };
    }
  ]);
  directives.directive('newWidgetForm', [
    'Query',
    'Widget',
    'growl',
    function (Query, Widget, growl) {
      return {
        restrict: 'E',
        scope: { dashboard: '=' },
        templateUrl: '/views/new_widget_form.html',
        replace: true,
        link: function ($scope, element, attrs) {
          $scope.widgetSizes = [
            {
              name: 'Regular',
              value: 1
            },
            {
              name: 'Double',
              value: 2
            }
          ];
          $scope.type = 'visualization';
          $scope.isVisualization = function () {
            return $scope.type == 'visualization';
          };
          $scope.isTextBox = function () {
            return $scope.type == 'textbox';
          };
          $scope.setType = function (type) {
            $scope.type = type;
          };
          var reset = function () {
            $scope.saveInProgress = false;
            $scope.widgetSize = 1;
            $scope.selectedVis = null;
            $scope.query = {};
            $scope.selected_query = undefined;
            $scope.text = '';
          };
          reset();
          $scope.loadVisualizations = function () {
            if (!$scope.query.selected) {
              return;
            }
            Query.get({ id: $scope.query.selected.id }, function (query) {
              if (query) {
                $scope.selected_query = query;
                if (query.visualizations.length) {
                  $scope.selectedVis = query.visualizations[0];
                }
              }
            });
          };
          $scope.searchQueries = function (term) {
            if (!term || term.length < 3) {
              return;
            }
            Query.search({ q: term }, function (results) {
              $scope.queries = results;
            });
          };
          $scope.$watch('query', function () {
            $scope.loadVisualizations();
          }, true);
          $scope.saveWidget = function () {
            $scope.saveInProgress = true;
            var widget = new Widget({
                'visualization_id': $scope.selectedVis && $scope.selectedVis.id,
                'dashboard_id': $scope.dashboard.id,
                'options': {},
                'width': $scope.widgetSize,
                'text': $scope.text
              });
            widget.$save().then(function (response) {
              // update dashboard layout
              $scope.dashboard.layout = response['layout'];
              var newWidget = new Widget(response['widget']);
              if (response['new_row']) {
                $scope.dashboard.widgets.push([newWidget]);
              } else {
                $scope.dashboard.widgets[$scope.dashboard.widgets.length - 1].push(newWidget);
              }
              // close the dialog
              $('#add_query_dialog').modal('hide');
              reset();
            }).catch(function () {
              growl.addErrorMessage('Widget can not be added');
            }).finally(function () {
              $scope.saveInProgress = false;
            });
          };
        }
      };
    }
  ]);
}());
var durationHumanize = function (duration) {
  var humanized = '';
  if (duration == undefined) {
    humanized = '-';
  } else if (duration < 60) {
    humanized = Math.round(duration) + 's';
  } else if (duration > 3600 * 24) {
    var days = Math.round(parseFloat(duration) / 60 / 60 / 24);
    humanized = days + 'days';
  } else if (duration >= 3600) {
    var hours = Math.round(parseFloat(duration) / 60 / 60);
    humanized = hours + 'h';
  } else {
    var minutes = Math.round(parseFloat(duration) / 60);
    humanized = minutes + 'm';
  }
  return humanized;
};
var urlPattern = /(^|[\s\n]|<br\/?>)((?:https?|ftp):\/\/[\-A-Z0-9+\u0026\u2019@#\/%?=()~_|!:,.;]*[\-A-Z0-9+\u0026@#\/%=~()_|])/gi;
angular.module('redash.filters', []).filter('durationHumanize', function () {
  return durationHumanize;
}).filter('scheduleHumanize', function () {
  return function (schedule) {
    if (schedule === null) {
      return 'Never';
    } else if (schedule.match(/\d\d:\d\d/) !== null) {
      var parts = schedule.split(':');
      var localTime = moment.utc().hour(parts[0]).minute(parts[1]).local().format('HH:mm');
      return 'Every day at ' + localTime;
    }
    return 'Every ' + durationHumanize(parseInt(schedule));
  };
}).filter('toHuman', function () {
  return function (text) {
    return text.replace(/_/g, ' ').replace(/(?:^|\s)\S/g, function (a) {
      return a.toUpperCase();
    });
  };
}).filter('colWidth', function () {
  return function (widgetWidth) {
    if (widgetWidth == 1) {
      return 6;
    }
    return 12;
  };
}).filter('capitalize', function () {
  return function (text) {
    if (text) {
      return _.str.capitalize(text);
    } else {
      return null;
    }
  };
}).filter('linkify', function () {
  return function (text) {
    return text.replace(urlPattern, '$1<a href=\'$2\' target=\'_blank\'>$2</a>');
  };
}).filter('markdown', [
  '$sce',
  function ($sce) {
    return function (text) {
      if (!text) {
        return '';
      }
      var html = marked(text);
      if (featureFlags.allowScriptsInUserInput) {
        html = $sce.trustAsHtml(html);
      }
      return html;
    };
  }
]).filter('trustAsHtml', [
  '$sce',
  function ($sce) {
    return function (text) {
      if (!text) {
        return '';
      }
      return $sce.trustAsHtml(text);
    };
  }
]);
(function () {
  var AlertsCtrl = function ($scope, Events, Alert) {
    Events.record(currentUser, 'view', 'page', 'alerts');
    $scope.$parent.pageTitle = 'Alerts';
    $scope.alerts = [];
    Alert.query(function (alerts) {
      var stateClass = {
          'ok': 'label label-success',
          'triggered': 'label label-danger',
          'unknown': 'label label-warning'
        };
      _.each(alerts, function (alert) {
        alert.class = stateClass[alert.state];
      });
      $scope.alerts = alerts;
    });
    $scope.gridConfig = {
      isPaginationEnabled: true,
      itemsByPage: 50,
      maxSize: 8
    };
    $scope.gridColumns = [
      {
        'label': 'Name',
        'map': 'name',
        'cellTemplate': '<a href="/alerts/{{dataRow.id}}">{{dataRow.name}}</a> (<a href="/queries/{{dataRow.query.id}}">query</a>)'
      },
      {
        'label': 'Created By',
        'map': 'user.name'
      },
      {
        'label': 'State',
        'cellTemplate': '<span ng-class="dataRow.class">{{dataRow.state | uppercase}}</span> since <span am-time-ago="dataRow.updated_at"></span>'
      },
      {
        'label': 'Created At',
        'cellTemplate': '<span am-time-ago="dataRow.created_at"></span>'
      }
    ];
  };
  var AlertCtrl = function ($scope, $routeParams, $location, growl, Query, Events, Alert) {
    $scope.$parent.pageTitle = 'Alerts';
    $scope.alertId = $routeParams.alertId;
    if ($scope.alertId === 'new') {
      Events.record(currentUser, 'view', 'page', 'alerts/new');
    } else {
      Events.record(currentUser, 'view', 'alert', $scope.alertId);
    }
    $scope.onQuerySelected = function (item) {
      $scope.selectedQuery = item;
      item.getQueryResultPromise().then(function (result) {
        $scope.queryResult = result;
        $scope.alert.options.column = $scope.alert.options.column || result.getColumnNames()[0];
      });
    };
    if ($scope.alertId === 'new') {
      $scope.alert = new Alert({ options: {} });
    } else {
      $scope.alert = Alert.get({ id: $scope.alertId }, function (alert) {
        $scope.onQuerySelected(new Query($scope.alert.query));
      });
    }
    $scope.ops = [
      'greater than',
      'less than',
      'equals'
    ];
    $scope.selectedQuery = null;
    $scope.getDefaultName = function () {
      if (!$scope.alert.query) {
        return undefined;
      }
      return _.template('<%= query.name %>: <%= options.column %> <%= options.op %> <%= options.value %>', $scope.alert);
    };
    $scope.searchQueries = function (term) {
      if (!term || term.length < 3) {
        return;
      }
      Query.search({ q: term }, function (results) {
        $scope.queries = results;
      });
    };
    $scope.saveChanges = function () {
      if ($scope.alert.name === undefined || $scope.alert.name === '') {
        $scope.alert.name = $scope.getDefaultName();
      }
      $scope.alert.$save(function (alert) {
        growl.addSuccessMessage('Saved.');
        if ($scope.alertId === 'new') {
          $location.path('/alerts/' + alert.id).replace();
        }
      }, function () {
        growl.addErrorMessage('Failed saving alert.');
      });
    };
  };
  angular.module('redash.directives').directive('alertSubscribers', [
    'AlertSubscription',
    function (AlertSubscription) {
      return {
        restrict: 'E',
        replace: true,
        templateUrl: '/views/alerts/subscribers.html',
        scope: { 'alertId': '=' },
        controller: [
          '$scope',
          function ($scope) {
            $scope.subscribers = AlertSubscription.query({ alertId: $scope.alertId });
          }
        ]
      };
    }
  ]);
  angular.module('redash.directives').directive('subscribeButton', [
    'AlertSubscription',
    'growl',
    function (AlertSubscription, growl) {
      return {
        restrict: 'E',
        replace: true,
        template: '<button class="btn btn-default btn-xs" ng-click="toggleSubscription()"><i ng-class="class"></i></button>',
        controller: [
          '$scope',
          function ($scope) {
            var updateClass = function () {
              if ($scope.subscription) {
                $scope.class = 'fa fa-eye-slash';
              } else {
                $scope.class = 'fa fa-eye';
              }
            };
            $scope.subscribers.$promise.then(function () {
              $scope.subscription = _.find($scope.subscribers, function (subscription) {
                return subscription.user.email == currentUser.email;
              });
              updateClass();
            });
            $scope.toggleSubscription = function () {
              if ($scope.subscription) {
                $scope.subscription.$delete(function () {
                  $scope.subscribers = _.without($scope.subscribers, $scope.subscription);
                  $scope.subscription = undefined;
                  updateClass();
                }, function () {
                  growl.addErrorMessage('Failed saving subscription.');
                });
              } else {
                $scope.subscription = new AlertSubscription({ alert_id: $scope.alertId });
                $scope.subscription.$save(function () {
                  $scope.subscribers.push($scope.subscription);
                  updateClass();
                }, function () {
                  growl.addErrorMessage('Unsubscription failed.');
                });
              }
            };
          }
        ]
      };
    }
  ]);
  angular.module('redash.controllers').controller('AlertsCtrl', [
    '$scope',
    'Events',
    'Alert',
    AlertsCtrl
  ]).controller('AlertCtrl', [
    '$scope',
    '$routeParams',
    '$location',
    'growl',
    'Query',
    'Events',
    'Alert',
    AlertCtrl
  ]);
}());